--
-- PostgreSQL database dump
--

\restrict qzmtuFdXyNwERvAvhn6bgXDqz82f0R0b8OG2BQoYaH9s0ZrURQ5AXJqeWdEeMP6

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY stripe.tax_ids DROP CONSTRAINT IF EXISTS fk_tax_ids_account;
ALTER TABLE IF EXISTS ONLY stripe._sync_status DROP CONSTRAINT IF EXISTS fk_sync_status_account;
ALTER TABLE IF EXISTS ONLY stripe.subscriptions DROP CONSTRAINT IF EXISTS fk_subscriptions_account;
ALTER TABLE IF EXISTS ONLY stripe.subscription_schedules DROP CONSTRAINT IF EXISTS fk_subscription_schedules_account;
ALTER TABLE IF EXISTS ONLY stripe.subscription_items DROP CONSTRAINT IF EXISTS fk_subscription_items_account;
ALTER TABLE IF EXISTS ONLY stripe.setup_intents DROP CONSTRAINT IF EXISTS fk_setup_intents_account;
ALTER TABLE IF EXISTS ONLY stripe.reviews DROP CONSTRAINT IF EXISTS fk_reviews_account;
ALTER TABLE IF EXISTS ONLY stripe.refunds DROP CONSTRAINT IF EXISTS fk_refunds_account;
ALTER TABLE IF EXISTS ONLY stripe.products DROP CONSTRAINT IF EXISTS fk_products_account;
ALTER TABLE IF EXISTS ONLY stripe.prices DROP CONSTRAINT IF EXISTS fk_prices_account;
ALTER TABLE IF EXISTS ONLY stripe.plans DROP CONSTRAINT IF EXISTS fk_plans_account;
ALTER TABLE IF EXISTS ONLY stripe.payment_methods DROP CONSTRAINT IF EXISTS fk_payment_methods_account;
ALTER TABLE IF EXISTS ONLY stripe.payment_intents DROP CONSTRAINT IF EXISTS fk_payment_intents_account;
ALTER TABLE IF EXISTS ONLY stripe._managed_webhooks DROP CONSTRAINT IF EXISTS fk_managed_webhooks_account;
ALTER TABLE IF EXISTS ONLY stripe.invoices DROP CONSTRAINT IF EXISTS fk_invoices_account;
ALTER TABLE IF EXISTS ONLY stripe.features DROP CONSTRAINT IF EXISTS fk_features_account;
ALTER TABLE IF EXISTS ONLY stripe.early_fraud_warnings DROP CONSTRAINT IF EXISTS fk_early_fraud_warnings_account;
ALTER TABLE IF EXISTS ONLY stripe.disputes DROP CONSTRAINT IF EXISTS fk_disputes_account;
ALTER TABLE IF EXISTS ONLY stripe.customers DROP CONSTRAINT IF EXISTS fk_customers_account;
ALTER TABLE IF EXISTS ONLY stripe.credit_notes DROP CONSTRAINT IF EXISTS fk_credit_notes_account;
ALTER TABLE IF EXISTS ONLY stripe.checkout_sessions DROP CONSTRAINT IF EXISTS fk_checkout_sessions_account;
ALTER TABLE IF EXISTS ONLY stripe.checkout_session_line_items DROP CONSTRAINT IF EXISTS fk_checkout_session_line_items_account;
ALTER TABLE IF EXISTS ONLY stripe.charges DROP CONSTRAINT IF EXISTS fk_charges_account;
ALTER TABLE IF EXISTS ONLY stripe.active_entitlements DROP CONSTRAINT IF EXISTS fk_active_entitlements_account;
DROP TRIGGER IF EXISTS handle_updated_at ON stripe.subscriptions;
DROP TRIGGER IF EXISTS handle_updated_at ON stripe.reviews;
DROP TRIGGER IF EXISTS handle_updated_at ON stripe.refunds;
DROP TRIGGER IF EXISTS handle_updated_at ON stripe.products;
DROP TRIGGER IF EXISTS handle_updated_at ON stripe.prices;
DROP TRIGGER IF EXISTS handle_updated_at ON stripe.plans;
DROP TRIGGER IF EXISTS handle_updated_at ON stripe.payouts;
DROP TRIGGER IF EXISTS handle_updated_at ON stripe.invoices;
DROP TRIGGER IF EXISTS handle_updated_at ON stripe.features;
DROP TRIGGER IF EXISTS handle_updated_at ON stripe.events;
DROP TRIGGER IF EXISTS handle_updated_at ON stripe.early_fraud_warnings;
DROP TRIGGER IF EXISTS handle_updated_at ON stripe.disputes;
DROP TRIGGER IF EXISTS handle_updated_at ON stripe.customers;
DROP TRIGGER IF EXISTS handle_updated_at ON stripe.coupons;
DROP TRIGGER IF EXISTS handle_updated_at ON stripe.checkout_sessions;
DROP TRIGGER IF EXISTS handle_updated_at ON stripe.checkout_session_line_items;
DROP TRIGGER IF EXISTS handle_updated_at ON stripe.charges;
DROP TRIGGER IF EXISTS handle_updated_at ON stripe.active_entitlements;
DROP TRIGGER IF EXISTS handle_updated_at ON stripe.accounts;
DROP TRIGGER IF EXISTS handle_updated_at ON stripe._sync_status;
DROP TRIGGER IF EXISTS handle_updated_at ON stripe._managed_webhooks;
DROP INDEX IF EXISTS stripe.stripe_tax_ids_customer_idx;
DROP INDEX IF EXISTS stripe.stripe_setup_intents_customer_idx;
DROP INDEX IF EXISTS stripe.stripe_reviews_payment_intent_idx;
DROP INDEX IF EXISTS stripe.stripe_reviews_charge_idx;
DROP INDEX IF EXISTS stripe.stripe_refunds_payment_intent_idx;
DROP INDEX IF EXISTS stripe.stripe_refunds_charge_idx;
DROP INDEX IF EXISTS stripe.stripe_payment_methods_customer_idx;
DROP INDEX IF EXISTS stripe.stripe_payment_intents_invoice_idx;
DROP INDEX IF EXISTS stripe.stripe_payment_intents_customer_idx;
DROP INDEX IF EXISTS stripe.stripe_managed_webhooks_status_idx;
DROP INDEX IF EXISTS stripe.stripe_managed_webhooks_enabled_idx;
DROP INDEX IF EXISTS stripe.stripe_invoices_subscription_idx;
DROP INDEX IF EXISTS stripe.stripe_invoices_customer_idx;
DROP INDEX IF EXISTS stripe.stripe_early_fraud_warnings_payment_intent_idx;
DROP INDEX IF EXISTS stripe.stripe_early_fraud_warnings_charge_idx;
DROP INDEX IF EXISTS stripe.stripe_dispute_created_idx;
DROP INDEX IF EXISTS stripe.stripe_credit_notes_invoice_idx;
DROP INDEX IF EXISTS stripe.stripe_credit_notes_customer_idx;
DROP INDEX IF EXISTS stripe.stripe_checkout_sessions_subscription_idx;
DROP INDEX IF EXISTS stripe.stripe_checkout_sessions_payment_intent_idx;
DROP INDEX IF EXISTS stripe.stripe_checkout_sessions_invoice_idx;
DROP INDEX IF EXISTS stripe.stripe_checkout_sessions_customer_idx;
DROP INDEX IF EXISTS stripe.stripe_checkout_session_line_items_session_idx;
DROP INDEX IF EXISTS stripe.stripe_checkout_session_line_items_price_idx;
DROP INDEX IF EXISTS stripe.stripe_active_entitlements_feature_idx;
DROP INDEX IF EXISTS stripe.stripe_active_entitlements_customer_idx;
DROP INDEX IF EXISTS stripe.idx_sync_status_resource_account;
DROP INDEX IF EXISTS stripe.idx_accounts_business_name;
DROP INDEX IF EXISTS stripe.idx_accounts_api_key_hashes;
DROP INDEX IF EXISTS stripe.features_lookup_key_key;
DROP INDEX IF EXISTS stripe.active_entitlements_lookup_key_key;
DROP INDEX IF EXISTS public.whatsapp_messages_order_type_uniq;
ALTER TABLE IF EXISTS ONLY stripe.tax_ids DROP CONSTRAINT IF EXISTS tax_ids_pkey;
ALTER TABLE IF EXISTS ONLY stripe.subscriptions DROP CONSTRAINT IF EXISTS subscriptions_pkey;
ALTER TABLE IF EXISTS ONLY stripe.subscription_schedules DROP CONSTRAINT IF EXISTS subscription_schedules_pkey;
ALTER TABLE IF EXISTS ONLY stripe.subscription_items DROP CONSTRAINT IF EXISTS subscription_items_pkey;
ALTER TABLE IF EXISTS ONLY stripe.setup_intents DROP CONSTRAINT IF EXISTS setup_intents_pkey;
ALTER TABLE IF EXISTS ONLY stripe.reviews DROP CONSTRAINT IF EXISTS reviews_pkey;
ALTER TABLE IF EXISTS ONLY stripe.refunds DROP CONSTRAINT IF EXISTS refunds_pkey;
ALTER TABLE IF EXISTS ONLY stripe.products DROP CONSTRAINT IF EXISTS products_pkey;
ALTER TABLE IF EXISTS ONLY stripe.prices DROP CONSTRAINT IF EXISTS prices_pkey;
ALTER TABLE IF EXISTS ONLY stripe.plans DROP CONSTRAINT IF EXISTS plans_pkey;
ALTER TABLE IF EXISTS ONLY stripe.payouts DROP CONSTRAINT IF EXISTS payouts_pkey;
ALTER TABLE IF EXISTS ONLY stripe.payment_methods DROP CONSTRAINT IF EXISTS payment_methods_pkey;
ALTER TABLE IF EXISTS ONLY stripe.payment_intents DROP CONSTRAINT IF EXISTS payment_intents_pkey;
ALTER TABLE IF EXISTS ONLY stripe._managed_webhooks DROP CONSTRAINT IF EXISTS managed_webhooks_url_account_unique;
ALTER TABLE IF EXISTS ONLY stripe._managed_webhooks DROP CONSTRAINT IF EXISTS managed_webhooks_pkey;
ALTER TABLE IF EXISTS ONLY stripe.invoices DROP CONSTRAINT IF EXISTS invoices_pkey;
ALTER TABLE IF EXISTS ONLY stripe.features DROP CONSTRAINT IF EXISTS features_pkey;
ALTER TABLE IF EXISTS ONLY stripe.events DROP CONSTRAINT IF EXISTS events_pkey;
ALTER TABLE IF EXISTS ONLY stripe.early_fraud_warnings DROP CONSTRAINT IF EXISTS early_fraud_warnings_pkey;
ALTER TABLE IF EXISTS ONLY stripe.disputes DROP CONSTRAINT IF EXISTS disputes_pkey;
ALTER TABLE IF EXISTS ONLY stripe.customers DROP CONSTRAINT IF EXISTS customers_pkey;
ALTER TABLE IF EXISTS ONLY stripe.credit_notes DROP CONSTRAINT IF EXISTS credit_notes_pkey;
ALTER TABLE IF EXISTS ONLY stripe.coupons DROP CONSTRAINT IF EXISTS coupons_pkey;
ALTER TABLE IF EXISTS ONLY stripe.checkout_sessions DROP CONSTRAINT IF EXISTS checkout_sessions_pkey;
ALTER TABLE IF EXISTS ONLY stripe.checkout_session_line_items DROP CONSTRAINT IF EXISTS checkout_session_line_items_pkey;
ALTER TABLE IF EXISTS ONLY stripe.charges DROP CONSTRAINT IF EXISTS charges_pkey;
ALTER TABLE IF EXISTS ONLY stripe.active_entitlements DROP CONSTRAINT IF EXISTS active_entitlements_pkey;
ALTER TABLE IF EXISTS ONLY stripe.accounts DROP CONSTRAINT IF EXISTS accounts_pkey;
ALTER TABLE IF EXISTS ONLY stripe._sync_status DROP CONSTRAINT IF EXISTS _sync_status_resource_account_key;
ALTER TABLE IF EXISTS ONLY stripe._sync_status DROP CONSTRAINT IF EXISTS _sync_status_pkey;
ALTER TABLE IF EXISTS ONLY stripe._migrations DROP CONSTRAINT IF EXISTS _migrations_pkey;
ALTER TABLE IF EXISTS ONLY stripe._migrations DROP CONSTRAINT IF EXISTS _migrations_name_key;
ALTER TABLE IF EXISTS ONLY public.whatsapp_messages DROP CONSTRAINT IF EXISTS whatsapp_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_unique;
ALTER TABLE IF EXISTS ONLY public.shipments DROP CONSTRAINT IF EXISTS shipments_pkey;
ALTER TABLE IF EXISTS ONLY public.quote_history DROP CONSTRAINT IF EXISTS quote_history_pkey;
ALTER TABLE IF EXISTS ONLY public.product_materials DROP CONSTRAINT IF EXISTS product_materials_product_code_unique;
ALTER TABLE IF EXISTS ONLY public.product_materials DROP CONSTRAINT IF EXISTS product_materials_pkey;
ALTER TABLE IF EXISTS ONLY public.processed_payments DROP CONSTRAINT IF EXISTS processed_payments_stripe_session_id_unique;
ALTER TABLE IF EXISTS ONLY public.processed_payments DROP CONSTRAINT IF EXISTS processed_payments_pkey;
ALTER TABLE IF EXISTS ONLY public.platform_settings DROP CONSTRAINT IF EXISTS platform_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.platform_settings DROP CONSTRAINT IF EXISTS platform_settings_key_unique;
ALTER TABLE IF EXISTS ONLY public.payment_orders DROP CONSTRAINT IF EXISTS payment_orders_pkey;
ALTER TABLE IF EXISTS ONLY public.payment_orders DROP CONSTRAINT IF EXISTS payment_orders_asaas_payment_id_unique;
ALTER TABLE IF EXISTS ONLY public.monetizze_orders DROP CONSTRAINT IF EXISTS monetizze_orders_sale_code_unique;
ALTER TABLE IF EXISTS ONLY public.monetizze_orders DROP CONSTRAINT IF EXISTS monetizze_orders_pkey;
ALTER TABLE IF EXISTS ONLY public.email_logs DROP CONSTRAINT IF EXISTS email_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.cart_items DROP CONSTRAINT IF EXISTS cart_items_pkey;
ALTER TABLE IF EXISTS stripe._sync_status ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.whatsapp_messages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.shipments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.quote_history ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.product_materials ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.processed_payments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.platform_settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.payment_orders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.monetizze_orders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.email_logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cart_items ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS stripe.tax_ids;
DROP TABLE IF EXISTS stripe.subscriptions;
DROP TABLE IF EXISTS stripe.subscription_schedules;
DROP TABLE IF EXISTS stripe.subscription_items;
DROP TABLE IF EXISTS stripe.setup_intents;
DROP TABLE IF EXISTS stripe.reviews;
DROP TABLE IF EXISTS stripe.refunds;
DROP TABLE IF EXISTS stripe.products;
DROP TABLE IF EXISTS stripe.prices;
DROP TABLE IF EXISTS stripe.plans;
DROP TABLE IF EXISTS stripe.payouts;
DROP TABLE IF EXISTS stripe.payment_methods;
DROP TABLE IF EXISTS stripe.payment_intents;
DROP TABLE IF EXISTS stripe.invoices;
DROP TABLE IF EXISTS stripe.features;
DROP TABLE IF EXISTS stripe.events;
DROP TABLE IF EXISTS stripe.early_fraud_warnings;
DROP TABLE IF EXISTS stripe.disputes;
DROP TABLE IF EXISTS stripe.customers;
DROP TABLE IF EXISTS stripe.credit_notes;
DROP TABLE IF EXISTS stripe.coupons;
DROP TABLE IF EXISTS stripe.checkout_sessions;
DROP TABLE IF EXISTS stripe.checkout_session_line_items;
DROP TABLE IF EXISTS stripe.charges;
DROP TABLE IF EXISTS stripe.active_entitlements;
DROP TABLE IF EXISTS stripe.accounts;
DROP SEQUENCE IF EXISTS stripe._sync_status_id_seq;
DROP TABLE IF EXISTS stripe._sync_status;
DROP TABLE IF EXISTS stripe._migrations;
DROP TABLE IF EXISTS stripe._managed_webhooks;
DROP SEQUENCE IF EXISTS public.whatsapp_messages_id_seq;
DROP TABLE IF EXISTS public.whatsapp_messages;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.shipments_id_seq;
DROP TABLE IF EXISTS public.shipments;
DROP SEQUENCE IF EXISTS public.quote_history_id_seq;
DROP TABLE IF EXISTS public.quote_history;
DROP SEQUENCE IF EXISTS public.product_materials_id_seq;
DROP TABLE IF EXISTS public.product_materials;
DROP SEQUENCE IF EXISTS public.processed_payments_id_seq;
DROP TABLE IF EXISTS public.processed_payments;
DROP SEQUENCE IF EXISTS public.platform_settings_id_seq;
DROP TABLE IF EXISTS public.platform_settings;
DROP SEQUENCE IF EXISTS public.payment_orders_id_seq;
DROP TABLE IF EXISTS public.payment_orders;
DROP SEQUENCE IF EXISTS public.monetizze_orders_id_seq;
DROP TABLE IF EXISTS public.monetizze_orders;
DROP SEQUENCE IF EXISTS public.email_logs_id_seq;
DROP TABLE IF EXISTS public.email_logs;
DROP SEQUENCE IF EXISTS public.cart_items_id_seq;
DROP TABLE IF EXISTS public.cart_items;
DROP FUNCTION IF EXISTS public.set_updated_at_metadata();
DROP FUNCTION IF EXISTS public.set_updated_at();
DROP TYPE IF EXISTS stripe.subscription_status;
DROP TYPE IF EXISTS stripe.subscription_schedule_status;
DROP TYPE IF EXISTS stripe.pricing_type;
DROP TYPE IF EXISTS stripe.pricing_tiers;
DROP TYPE IF EXISTS stripe.invoice_status;
DROP SCHEMA IF EXISTS stripe;
--
-- Name: stripe; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA stripe;


--
-- Name: invoice_status; Type: TYPE; Schema: stripe; Owner: -
--

CREATE TYPE stripe.invoice_status AS ENUM (
    'draft',
    'open',
    'paid',
    'uncollectible',
    'void',
    'deleted'
);


--
-- Name: pricing_tiers; Type: TYPE; Schema: stripe; Owner: -
--

CREATE TYPE stripe.pricing_tiers AS ENUM (
    'graduated',
    'volume'
);


--
-- Name: pricing_type; Type: TYPE; Schema: stripe; Owner: -
--

CREATE TYPE stripe.pricing_type AS ENUM (
    'one_time',
    'recurring'
);


--
-- Name: subscription_schedule_status; Type: TYPE; Schema: stripe; Owner: -
--

CREATE TYPE stripe.subscription_schedule_status AS ENUM (
    'not_started',
    'active',
    'completed',
    'released',
    'canceled'
);


--
-- Name: subscription_status; Type: TYPE; Schema: stripe; Owner: -
--

CREATE TYPE stripe.subscription_status AS ENUM (
    'trialing',
    'active',
    'canceled',
    'incomplete',
    'incomplete_expired',
    'past_due',
    'unpaid',
    'paused'
);


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  new._updated_at = now();
  return NEW;
end;
$$;


--
-- Name: set_updated_at_metadata(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_updated_at_metadata() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  new.updated_at = now();
  return NEW;
end;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cart_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cart_items (
    id integer NOT NULL,
    user_id integer NOT NULL,
    recipient_name text NOT NULL,
    recipient_phone text DEFAULT ''::text NOT NULL,
    recipient_cpf_cnpj text DEFAULT ''::text NOT NULL,
    address text NOT NULL,
    carrier text NOT NULL,
    original_price numeric(10,2) NOT NULL,
    final_price numeric(10,2) NOT NULL,
    delivery_time integer NOT NULL,
    origin_zip text DEFAULT ''::text NOT NULL,
    dest_zip text DEFAULT ''::text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    content_declaration text DEFAULT ''::text NOT NULL,
    invoice_number text DEFAULT ''::text NOT NULL,
    weight numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    height numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    width numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    length numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    sender_full_address text DEFAULT ''::text NOT NULL,
    service_code text,
    carrier_code text,
    declared_value numeric(10,2),
    sender_cpf_cnpj text DEFAULT ''::text NOT NULL,
    volumes integer DEFAULT 1 NOT NULL
);


--
-- Name: cart_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cart_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cart_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cart_items_id_seq OWNED BY public.cart_items.id;


--
-- Name: email_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_logs (
    id integer NOT NULL,
    to_address text NOT NULL,
    from_address text NOT NULL,
    subject text NOT NULL,
    html text,
    text_body text,
    status text DEFAULT 'sent'::text NOT NULL,
    provider text DEFAULT 'resend'::text NOT NULL,
    provider_message_id text,
    error_message text,
    context text,
    related_user_id integer,
    related_shipment_id integer,
    related_monetizze_order_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: email_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_logs_id_seq OWNED BY public.email_logs.id;


--
-- Name: monetizze_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.monetizze_orders (
    id integer NOT NULL,
    sale_code text NOT NULL,
    product_code text,
    product_name text,
    owner_user_id integer NOT NULL,
    shipment_id integer,
    status text DEFAULT 'aguardando_envio'::text NOT NULL,
    kit_count integer DEFAULT 0 NOT NULL,
    weight numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    height numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    width numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    length numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    recipient_name text DEFAULT ''::text NOT NULL,
    recipient_email text DEFAULT ''::text NOT NULL,
    recipient_phone text DEFAULT ''::text NOT NULL,
    recipient_cpf_cnpj text DEFAULT ''::text NOT NULL,
    recipient_address text DEFAULT ''::text NOT NULL,
    recipient_zip text DEFAULT ''::text NOT NULL,
    carrier text,
    carrier_code text,
    service_code text,
    tracking_code text,
    tracking_eligible_at timestamp without time zone,
    tracking_sent_at timestamp without time zone,
    final_price numeric(10,2),
    sale_value numeric(10,2),
    retry_count integer DEFAULT 0 NOT NULL,
    last_error text,
    raw_payload jsonb,
    email_approved_sent_at timestamp without time zone,
    email_preparing_sent_at timestamp without time zone,
    email_shipped_sent_at timestamp without time zone,
    email_delivered_sent_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    email_out_for_delivery_sent_at timestamp without time zone,
    email_materials_sent_at timestamp without time zone,
    materials_processed_at timestamp without time zone,
    materials_emailed_codes text[] DEFAULT '{}'::text[] NOT NULL,
    tracking_notified_at timestamp without time zone
);


--
-- Name: monetizze_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.monetizze_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: monetizze_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.monetizze_orders_id_seq OWNED BY public.monetizze_orders.id;


--
-- Name: payment_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_orders (
    id integer NOT NULL,
    user_id integer NOT NULL,
    asaas_payment_id text NOT NULL,
    asaas_customer_id text,
    amount numeric(10,2) NOT NULL,
    method text NOT NULL,
    status text DEFAULT 'aguardando_pagamento'::text NOT NULL,
    pix_qr_code text,
    pix_copy_paste text,
    invoice_url text,
    created_at timestamp without time zone DEFAULT now(),
    paid_at timestamp without time zone,
    asaas_net_value numeric(10,2),
    asaas_fee numeric(10,2),
    frenet_share numeric(10,2),
    margin_share numeric(10,2),
    frenet_transferred_at timestamp without time zone
);


--
-- Name: payment_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_orders_id_seq OWNED BY public.payment_orders.id;


--
-- Name: platform_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.platform_settings (
    id integer NOT NULL,
    key text NOT NULL,
    value text NOT NULL
);


--
-- Name: platform_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.platform_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: platform_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.platform_settings_id_seq OWNED BY public.platform_settings.id;


--
-- Name: processed_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.processed_payments (
    id integer NOT NULL,
    stripe_session_id text NOT NULL,
    user_id integer NOT NULL,
    amount numeric(10,2) NOT NULL,
    processed_at timestamp without time zone DEFAULT now()
);


--
-- Name: processed_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.processed_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: processed_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.processed_payments_id_seq OWNED BY public.processed_payments.id;


--
-- Name: product_materials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_materials (
    id integer NOT NULL,
    product_code text NOT NULL,
    display_name text DEFAULT ''::text NOT NULL,
    store_name text DEFAULT ''::text NOT NULL,
    video_url text DEFAULT ''::text NOT NULL,
    manual_url text DEFAULT ''::text NOT NULL,
    training_url text DEFAULT ''::text NOT NULL,
    vip_group_url text DEFAULT ''::text NOT NULL,
    support_url text DEFAULT ''::text NOT NULL,
    warranty text DEFAULT ''::text NOT NULL,
    repurchase_url text DEFAULT ''::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: product_materials_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_materials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_materials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_materials_id_seq OWNED BY public.product_materials.id;


--
-- Name: quote_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quote_history (
    id integer NOT NULL,
    user_id integer NOT NULL,
    origin_zip text NOT NULL,
    dest_zip text NOT NULL,
    weight numeric(10,2) NOT NULL,
    height numeric(10,2) NOT NULL,
    width numeric(10,2) NOT NULL,
    length numeric(10,2) NOT NULL,
    carrier text NOT NULL,
    original_price numeric(10,2) NOT NULL,
    final_price numeric(10,2) NOT NULL,
    delivery_time integer NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: quote_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quote_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: quote_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quote_history_id_seq OWNED BY public.quote_history.id;


--
-- Name: shipments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shipments (
    id integer NOT NULL,
    user_id integer NOT NULL,
    recipient_name text NOT NULL,
    address text NOT NULL,
    carrier text NOT NULL,
    original_price numeric(10,2) NOT NULL,
    final_price numeric(10,2) NOT NULL,
    delivery_time integer NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    platform_profit numeric(10,2) DEFAULT 0.00 NOT NULL,
    status text DEFAULT 'aguardando_postagem'::text NOT NULL,
    tracking_code text,
    updated_at timestamp without time zone DEFAULT now(),
    recipient_phone text DEFAULT ''::text NOT NULL,
    recipient_cpf_cnpj text DEFAULT ''::text NOT NULL,
    origin_zip text DEFAULT ''::text NOT NULL,
    dest_zip text DEFAULT ''::text NOT NULL,
    content_declaration text DEFAULT ''::text NOT NULL,
    invoice_number text DEFAULT ''::text NOT NULL,
    weight numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    height numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    width numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    length numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    sender_full_address text DEFAULT ''::text NOT NULL,
    service_code text,
    carrier_code text,
    declared_value numeric(10,2),
    frenet_shipment_id text,
    frenet_label_url text,
    frenet_tracking_url text,
    sender_cpf_cnpj text DEFAULT ''::text NOT NULL,
    frenet_error_message text,
    frenet_declaration_url text,
    volumes integer DEFAULT 1 NOT NULL,
    hidden_at timestamp without time zone
);


--
-- Name: shipments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.shipments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: shipments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.shipments_id_seq OWNED BY public.shipments.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    cpf_cnpj text NOT NULL,
    balance numeric(10,2) DEFAULT 0.00 NOT NULL,
    role text DEFAULT 'user'::text NOT NULL,
    blocked boolean DEFAULT false NOT NULL,
    default_address text,
    phone text,
    email_verified boolean DEFAULT true NOT NULL,
    email_verification_token text,
    email_verification_token_expiry timestamp without time zone
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: whatsapp_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.whatsapp_messages (
    id integer NOT NULL,
    monetizze_order_id integer NOT NULL,
    type text NOT NULL,
    status text DEFAULT 'pendente'::text NOT NULL,
    phone text DEFAULT ''::text NOT NULL,
    recipient_name text DEFAULT ''::text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_error text,
    provider_message_id text,
    sent_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    product_code text DEFAULT ''::text NOT NULL
);


--
-- Name: whatsapp_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.whatsapp_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: whatsapp_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.whatsapp_messages_id_seq OWNED BY public.whatsapp_messages.id;


--
-- Name: _managed_webhooks; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe._managed_webhooks (
    id text NOT NULL,
    object text,
    url text NOT NULL,
    enabled_events jsonb NOT NULL,
    description text,
    enabled boolean,
    livemode boolean,
    metadata jsonb,
    secret text NOT NULL,
    status text,
    api_version text,
    created integer,
    updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    last_synced_at timestamp with time zone,
    account_id text NOT NULL
);


--
-- Name: _migrations; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe._migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: _sync_status; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe._sync_status (
    id integer NOT NULL,
    resource text NOT NULL,
    status text DEFAULT 'idle'::text,
    last_synced_at timestamp with time zone DEFAULT now(),
    last_incremental_cursor timestamp with time zone,
    error_message text,
    updated_at timestamp with time zone DEFAULT now(),
    account_id text NOT NULL,
    CONSTRAINT _sync_status_status_check CHECK ((status = ANY (ARRAY['idle'::text, 'running'::text, 'complete'::text, 'error'::text])))
);


--
-- Name: _sync_status_id_seq; Type: SEQUENCE; Schema: stripe; Owner: -
--

CREATE SEQUENCE stripe._sync_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: _sync_status_id_seq; Type: SEQUENCE OWNED BY; Schema: stripe; Owner: -
--

ALTER SEQUENCE stripe._sync_status_id_seq OWNED BY stripe._sync_status.id;


--
-- Name: accounts; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.accounts (
    _raw_data jsonb NOT NULL,
    first_synced_at timestamp with time zone DEFAULT now() NOT NULL,
    _last_synced_at timestamp with time zone DEFAULT now() NOT NULL,
    _updated_at timestamp with time zone DEFAULT now() NOT NULL,
    business_name text GENERATED ALWAYS AS (((_raw_data -> 'business_profile'::text) ->> 'name'::text)) STORED,
    email text GENERATED ALWAYS AS ((_raw_data ->> 'email'::text)) STORED,
    type text GENERATED ALWAYS AS ((_raw_data ->> 'type'::text)) STORED,
    charges_enabled boolean GENERATED ALWAYS AS (((_raw_data ->> 'charges_enabled'::text))::boolean) STORED,
    payouts_enabled boolean GENERATED ALWAYS AS (((_raw_data ->> 'payouts_enabled'::text))::boolean) STORED,
    details_submitted boolean GENERATED ALWAYS AS (((_raw_data ->> 'details_submitted'::text))::boolean) STORED,
    country text GENERATED ALWAYS AS ((_raw_data ->> 'country'::text)) STORED,
    default_currency text GENERATED ALWAYS AS ((_raw_data ->> 'default_currency'::text)) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    api_key_hashes text[] DEFAULT '{}'::text[],
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: active_entitlements; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.active_entitlements (
    _updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    _account_id text NOT NULL,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    livemode boolean GENERATED ALWAYS AS (((_raw_data ->> 'livemode'::text))::boolean) STORED,
    feature text GENERATED ALWAYS AS ((_raw_data ->> 'feature'::text)) STORED,
    customer text GENERATED ALWAYS AS ((_raw_data ->> 'customer'::text)) STORED,
    lookup_key text GENERATED ALWAYS AS ((_raw_data ->> 'lookup_key'::text)) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: charges; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.charges (
    _updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    _account_id text NOT NULL,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    paid boolean GENERATED ALWAYS AS (((_raw_data ->> 'paid'::text))::boolean) STORED,
    "order" text GENERATED ALWAYS AS ((_raw_data ->> 'order'::text)) STORED,
    amount bigint GENERATED ALWAYS AS (((_raw_data ->> 'amount'::text))::bigint) STORED,
    review text GENERATED ALWAYS AS ((_raw_data ->> 'review'::text)) STORED,
    source jsonb GENERATED ALWAYS AS ((_raw_data -> 'source'::text)) STORED,
    status text GENERATED ALWAYS AS ((_raw_data ->> 'status'::text)) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    dispute text GENERATED ALWAYS AS ((_raw_data ->> 'dispute'::text)) STORED,
    invoice text GENERATED ALWAYS AS ((_raw_data ->> 'invoice'::text)) STORED,
    outcome jsonb GENERATED ALWAYS AS ((_raw_data -> 'outcome'::text)) STORED,
    refunds jsonb GENERATED ALWAYS AS ((_raw_data -> 'refunds'::text)) STORED,
    updated integer GENERATED ALWAYS AS (((_raw_data ->> 'updated'::text))::integer) STORED,
    captured boolean GENERATED ALWAYS AS (((_raw_data ->> 'captured'::text))::boolean) STORED,
    currency text GENERATED ALWAYS AS ((_raw_data ->> 'currency'::text)) STORED,
    customer text GENERATED ALWAYS AS ((_raw_data ->> 'customer'::text)) STORED,
    livemode boolean GENERATED ALWAYS AS (((_raw_data ->> 'livemode'::text))::boolean) STORED,
    metadata jsonb GENERATED ALWAYS AS ((_raw_data -> 'metadata'::text)) STORED,
    refunded boolean GENERATED ALWAYS AS (((_raw_data ->> 'refunded'::text))::boolean) STORED,
    shipping jsonb GENERATED ALWAYS AS ((_raw_data -> 'shipping'::text)) STORED,
    application text GENERATED ALWAYS AS ((_raw_data ->> 'application'::text)) STORED,
    description text GENERATED ALWAYS AS ((_raw_data ->> 'description'::text)) STORED,
    destination text GENERATED ALWAYS AS ((_raw_data ->> 'destination'::text)) STORED,
    failure_code text GENERATED ALWAYS AS ((_raw_data ->> 'failure_code'::text)) STORED,
    on_behalf_of text GENERATED ALWAYS AS ((_raw_data ->> 'on_behalf_of'::text)) STORED,
    fraud_details jsonb GENERATED ALWAYS AS ((_raw_data -> 'fraud_details'::text)) STORED,
    receipt_email text GENERATED ALWAYS AS ((_raw_data ->> 'receipt_email'::text)) STORED,
    payment_intent text GENERATED ALWAYS AS ((_raw_data ->> 'payment_intent'::text)) STORED,
    receipt_number text GENERATED ALWAYS AS ((_raw_data ->> 'receipt_number'::text)) STORED,
    transfer_group text GENERATED ALWAYS AS ((_raw_data ->> 'transfer_group'::text)) STORED,
    amount_refunded bigint GENERATED ALWAYS AS (((_raw_data ->> 'amount_refunded'::text))::bigint) STORED,
    application_fee text GENERATED ALWAYS AS ((_raw_data ->> 'application_fee'::text)) STORED,
    failure_message text GENERATED ALWAYS AS ((_raw_data ->> 'failure_message'::text)) STORED,
    source_transfer text GENERATED ALWAYS AS ((_raw_data ->> 'source_transfer'::text)) STORED,
    balance_transaction text GENERATED ALWAYS AS ((_raw_data ->> 'balance_transaction'::text)) STORED,
    statement_descriptor text GENERATED ALWAYS AS ((_raw_data ->> 'statement_descriptor'::text)) STORED,
    payment_method_details jsonb GENERATED ALWAYS AS ((_raw_data -> 'payment_method_details'::text)) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: checkout_session_line_items; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.checkout_session_line_items (
    _updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    _account_id text NOT NULL,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    amount_discount integer GENERATED ALWAYS AS (((_raw_data ->> 'amount_discount'::text))::integer) STORED,
    amount_subtotal integer GENERATED ALWAYS AS (((_raw_data ->> 'amount_subtotal'::text))::integer) STORED,
    amount_tax integer GENERATED ALWAYS AS (((_raw_data ->> 'amount_tax'::text))::integer) STORED,
    amount_total integer GENERATED ALWAYS AS (((_raw_data ->> 'amount_total'::text))::integer) STORED,
    currency text GENERATED ALWAYS AS ((_raw_data ->> 'currency'::text)) STORED,
    description text GENERATED ALWAYS AS ((_raw_data ->> 'description'::text)) STORED,
    price text GENERATED ALWAYS AS ((_raw_data ->> 'price'::text)) STORED,
    quantity integer GENERATED ALWAYS AS (((_raw_data ->> 'quantity'::text))::integer) STORED,
    checkout_session text GENERATED ALWAYS AS ((_raw_data ->> 'checkout_session'::text)) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: checkout_sessions; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.checkout_sessions (
    _updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    _account_id text NOT NULL,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    adaptive_pricing jsonb GENERATED ALWAYS AS ((_raw_data -> 'adaptive_pricing'::text)) STORED,
    after_expiration jsonb GENERATED ALWAYS AS ((_raw_data -> 'after_expiration'::text)) STORED,
    allow_promotion_codes boolean GENERATED ALWAYS AS (((_raw_data ->> 'allow_promotion_codes'::text))::boolean) STORED,
    amount_subtotal integer GENERATED ALWAYS AS (((_raw_data ->> 'amount_subtotal'::text))::integer) STORED,
    amount_total integer GENERATED ALWAYS AS (((_raw_data ->> 'amount_total'::text))::integer) STORED,
    automatic_tax jsonb GENERATED ALWAYS AS ((_raw_data -> 'automatic_tax'::text)) STORED,
    billing_address_collection text GENERATED ALWAYS AS ((_raw_data ->> 'billing_address_collection'::text)) STORED,
    cancel_url text GENERATED ALWAYS AS ((_raw_data ->> 'cancel_url'::text)) STORED,
    client_reference_id text GENERATED ALWAYS AS ((_raw_data ->> 'client_reference_id'::text)) STORED,
    client_secret text GENERATED ALWAYS AS ((_raw_data ->> 'client_secret'::text)) STORED,
    collected_information jsonb GENERATED ALWAYS AS ((_raw_data -> 'collected_information'::text)) STORED,
    consent jsonb GENERATED ALWAYS AS ((_raw_data -> 'consent'::text)) STORED,
    consent_collection jsonb GENERATED ALWAYS AS ((_raw_data -> 'consent_collection'::text)) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    currency text GENERATED ALWAYS AS ((_raw_data ->> 'currency'::text)) STORED,
    currency_conversion jsonb GENERATED ALWAYS AS ((_raw_data -> 'currency_conversion'::text)) STORED,
    custom_fields jsonb GENERATED ALWAYS AS ((_raw_data -> 'custom_fields'::text)) STORED,
    custom_text jsonb GENERATED ALWAYS AS ((_raw_data -> 'custom_text'::text)) STORED,
    customer text GENERATED ALWAYS AS ((_raw_data ->> 'customer'::text)) STORED,
    customer_creation text GENERATED ALWAYS AS ((_raw_data ->> 'customer_creation'::text)) STORED,
    customer_details jsonb GENERATED ALWAYS AS ((_raw_data -> 'customer_details'::text)) STORED,
    customer_email text GENERATED ALWAYS AS ((_raw_data ->> 'customer_email'::text)) STORED,
    discounts jsonb GENERATED ALWAYS AS ((_raw_data -> 'discounts'::text)) STORED,
    expires_at integer GENERATED ALWAYS AS (((_raw_data ->> 'expires_at'::text))::integer) STORED,
    invoice text GENERATED ALWAYS AS ((_raw_data ->> 'invoice'::text)) STORED,
    invoice_creation jsonb GENERATED ALWAYS AS ((_raw_data -> 'invoice_creation'::text)) STORED,
    livemode boolean GENERATED ALWAYS AS (((_raw_data ->> 'livemode'::text))::boolean) STORED,
    locale text GENERATED ALWAYS AS ((_raw_data ->> 'locale'::text)) STORED,
    metadata jsonb GENERATED ALWAYS AS ((_raw_data -> 'metadata'::text)) STORED,
    mode text GENERATED ALWAYS AS ((_raw_data ->> 'mode'::text)) STORED,
    optional_items jsonb GENERATED ALWAYS AS ((_raw_data -> 'optional_items'::text)) STORED,
    payment_intent text GENERATED ALWAYS AS ((_raw_data ->> 'payment_intent'::text)) STORED,
    payment_link text GENERATED ALWAYS AS ((_raw_data ->> 'payment_link'::text)) STORED,
    payment_method_collection text GENERATED ALWAYS AS ((_raw_data ->> 'payment_method_collection'::text)) STORED,
    payment_method_configuration_details jsonb GENERATED ALWAYS AS ((_raw_data -> 'payment_method_configuration_details'::text)) STORED,
    payment_method_options jsonb GENERATED ALWAYS AS ((_raw_data -> 'payment_method_options'::text)) STORED,
    payment_method_types jsonb GENERATED ALWAYS AS ((_raw_data -> 'payment_method_types'::text)) STORED,
    payment_status text GENERATED ALWAYS AS ((_raw_data ->> 'payment_status'::text)) STORED,
    permissions jsonb GENERATED ALWAYS AS ((_raw_data -> 'permissions'::text)) STORED,
    phone_number_collection jsonb GENERATED ALWAYS AS ((_raw_data -> 'phone_number_collection'::text)) STORED,
    presentment_details jsonb GENERATED ALWAYS AS ((_raw_data -> 'presentment_details'::text)) STORED,
    recovered_from text GENERATED ALWAYS AS ((_raw_data ->> 'recovered_from'::text)) STORED,
    redirect_on_completion text GENERATED ALWAYS AS ((_raw_data ->> 'redirect_on_completion'::text)) STORED,
    return_url text GENERATED ALWAYS AS ((_raw_data ->> 'return_url'::text)) STORED,
    saved_payment_method_options jsonb GENERATED ALWAYS AS ((_raw_data -> 'saved_payment_method_options'::text)) STORED,
    setup_intent text GENERATED ALWAYS AS ((_raw_data ->> 'setup_intent'::text)) STORED,
    shipping_address_collection jsonb GENERATED ALWAYS AS ((_raw_data -> 'shipping_address_collection'::text)) STORED,
    shipping_cost jsonb GENERATED ALWAYS AS ((_raw_data -> 'shipping_cost'::text)) STORED,
    shipping_details jsonb GENERATED ALWAYS AS ((_raw_data -> 'shipping_details'::text)) STORED,
    shipping_options jsonb GENERATED ALWAYS AS ((_raw_data -> 'shipping_options'::text)) STORED,
    status text GENERATED ALWAYS AS ((_raw_data ->> 'status'::text)) STORED,
    submit_type text GENERATED ALWAYS AS ((_raw_data ->> 'submit_type'::text)) STORED,
    subscription text GENERATED ALWAYS AS ((_raw_data ->> 'subscription'::text)) STORED,
    success_url text GENERATED ALWAYS AS ((_raw_data ->> 'success_url'::text)) STORED,
    tax_id_collection jsonb GENERATED ALWAYS AS ((_raw_data -> 'tax_id_collection'::text)) STORED,
    total_details jsonb GENERATED ALWAYS AS ((_raw_data -> 'total_details'::text)) STORED,
    ui_mode text GENERATED ALWAYS AS ((_raw_data ->> 'ui_mode'::text)) STORED,
    url text GENERATED ALWAYS AS ((_raw_data ->> 'url'::text)) STORED,
    wallet_options jsonb GENERATED ALWAYS AS ((_raw_data -> 'wallet_options'::text)) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: coupons; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.coupons (
    _updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    name text GENERATED ALWAYS AS ((_raw_data ->> 'name'::text)) STORED,
    valid boolean GENERATED ALWAYS AS (((_raw_data ->> 'valid'::text))::boolean) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    updated integer GENERATED ALWAYS AS (((_raw_data ->> 'updated'::text))::integer) STORED,
    currency text GENERATED ALWAYS AS ((_raw_data ->> 'currency'::text)) STORED,
    duration text GENERATED ALWAYS AS ((_raw_data ->> 'duration'::text)) STORED,
    livemode boolean GENERATED ALWAYS AS (((_raw_data ->> 'livemode'::text))::boolean) STORED,
    metadata jsonb GENERATED ALWAYS AS ((_raw_data -> 'metadata'::text)) STORED,
    redeem_by integer GENERATED ALWAYS AS (((_raw_data ->> 'redeem_by'::text))::integer) STORED,
    amount_off bigint GENERATED ALWAYS AS (((_raw_data ->> 'amount_off'::text))::bigint) STORED,
    percent_off double precision GENERATED ALWAYS AS (((_raw_data ->> 'percent_off'::text))::double precision) STORED,
    times_redeemed bigint GENERATED ALWAYS AS (((_raw_data ->> 'times_redeemed'::text))::bigint) STORED,
    max_redemptions bigint GENERATED ALWAYS AS (((_raw_data ->> 'max_redemptions'::text))::bigint) STORED,
    duration_in_months bigint GENERATED ALWAYS AS (((_raw_data ->> 'duration_in_months'::text))::bigint) STORED,
    percent_off_precise double precision GENERATED ALWAYS AS (((_raw_data ->> 'percent_off_precise'::text))::double precision) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: credit_notes; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.credit_notes (
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    _account_id text NOT NULL,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    amount integer GENERATED ALWAYS AS (((_raw_data ->> 'amount'::text))::integer) STORED,
    amount_shipping integer GENERATED ALWAYS AS (((_raw_data ->> 'amount_shipping'::text))::integer) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    currency text GENERATED ALWAYS AS ((_raw_data ->> 'currency'::text)) STORED,
    customer text GENERATED ALWAYS AS ((_raw_data ->> 'customer'::text)) STORED,
    customer_balance_transaction text GENERATED ALWAYS AS ((_raw_data ->> 'customer_balance_transaction'::text)) STORED,
    discount_amount integer GENERATED ALWAYS AS (((_raw_data ->> 'discount_amount'::text))::integer) STORED,
    discount_amounts jsonb GENERATED ALWAYS AS ((_raw_data -> 'discount_amounts'::text)) STORED,
    invoice text GENERATED ALWAYS AS ((_raw_data ->> 'invoice'::text)) STORED,
    lines jsonb GENERATED ALWAYS AS ((_raw_data -> 'lines'::text)) STORED,
    livemode boolean GENERATED ALWAYS AS (((_raw_data ->> 'livemode'::text))::boolean) STORED,
    memo text GENERATED ALWAYS AS ((_raw_data ->> 'memo'::text)) STORED,
    metadata jsonb GENERATED ALWAYS AS ((_raw_data -> 'metadata'::text)) STORED,
    number text GENERATED ALWAYS AS ((_raw_data ->> 'number'::text)) STORED,
    out_of_band_amount integer GENERATED ALWAYS AS (((_raw_data ->> 'out_of_band_amount'::text))::integer) STORED,
    pdf text GENERATED ALWAYS AS ((_raw_data ->> 'pdf'::text)) STORED,
    reason text GENERATED ALWAYS AS ((_raw_data ->> 'reason'::text)) STORED,
    refund text GENERATED ALWAYS AS ((_raw_data ->> 'refund'::text)) STORED,
    shipping_cost jsonb GENERATED ALWAYS AS ((_raw_data -> 'shipping_cost'::text)) STORED,
    status text GENERATED ALWAYS AS ((_raw_data ->> 'status'::text)) STORED,
    subtotal integer GENERATED ALWAYS AS (((_raw_data ->> 'subtotal'::text))::integer) STORED,
    subtotal_excluding_tax integer GENERATED ALWAYS AS (((_raw_data ->> 'subtotal_excluding_tax'::text))::integer) STORED,
    tax_amounts jsonb GENERATED ALWAYS AS ((_raw_data -> 'tax_amounts'::text)) STORED,
    total integer GENERATED ALWAYS AS (((_raw_data ->> 'total'::text))::integer) STORED,
    total_excluding_tax integer GENERATED ALWAYS AS (((_raw_data ->> 'total_excluding_tax'::text))::integer) STORED,
    type text GENERATED ALWAYS AS ((_raw_data ->> 'type'::text)) STORED,
    voided_at text GENERATED ALWAYS AS ((_raw_data ->> 'voided_at'::text)) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: customers; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.customers (
    _updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    _account_id text NOT NULL,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    address jsonb GENERATED ALWAYS AS ((_raw_data -> 'address'::text)) STORED,
    description text GENERATED ALWAYS AS ((_raw_data ->> 'description'::text)) STORED,
    email text GENERATED ALWAYS AS ((_raw_data ->> 'email'::text)) STORED,
    metadata jsonb GENERATED ALWAYS AS ((_raw_data -> 'metadata'::text)) STORED,
    name text GENERATED ALWAYS AS ((_raw_data ->> 'name'::text)) STORED,
    phone text GENERATED ALWAYS AS ((_raw_data ->> 'phone'::text)) STORED,
    shipping jsonb GENERATED ALWAYS AS ((_raw_data -> 'shipping'::text)) STORED,
    balance integer GENERATED ALWAYS AS (((_raw_data ->> 'balance'::text))::integer) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    currency text GENERATED ALWAYS AS ((_raw_data ->> 'currency'::text)) STORED,
    default_source text GENERATED ALWAYS AS ((_raw_data ->> 'default_source'::text)) STORED,
    delinquent boolean GENERATED ALWAYS AS (((_raw_data ->> 'delinquent'::text))::boolean) STORED,
    discount jsonb GENERATED ALWAYS AS ((_raw_data -> 'discount'::text)) STORED,
    invoice_prefix text GENERATED ALWAYS AS ((_raw_data ->> 'invoice_prefix'::text)) STORED,
    invoice_settings jsonb GENERATED ALWAYS AS ((_raw_data -> 'invoice_settings'::text)) STORED,
    livemode boolean GENERATED ALWAYS AS (((_raw_data ->> 'livemode'::text))::boolean) STORED,
    next_invoice_sequence integer GENERATED ALWAYS AS (((_raw_data ->> 'next_invoice_sequence'::text))::integer) STORED,
    preferred_locales jsonb GENERATED ALWAYS AS ((_raw_data -> 'preferred_locales'::text)) STORED,
    tax_exempt text GENERATED ALWAYS AS ((_raw_data ->> 'tax_exempt'::text)) STORED,
    deleted boolean GENERATED ALWAYS AS (((_raw_data ->> 'deleted'::text))::boolean) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: disputes; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.disputes (
    _updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    _account_id text NOT NULL,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    amount bigint GENERATED ALWAYS AS (((_raw_data ->> 'amount'::text))::bigint) STORED,
    charge text GENERATED ALWAYS AS ((_raw_data ->> 'charge'::text)) STORED,
    reason text GENERATED ALWAYS AS ((_raw_data ->> 'reason'::text)) STORED,
    status text GENERATED ALWAYS AS ((_raw_data ->> 'status'::text)) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    updated integer GENERATED ALWAYS AS (((_raw_data ->> 'updated'::text))::integer) STORED,
    currency text GENERATED ALWAYS AS ((_raw_data ->> 'currency'::text)) STORED,
    evidence jsonb GENERATED ALWAYS AS ((_raw_data -> 'evidence'::text)) STORED,
    livemode boolean GENERATED ALWAYS AS (((_raw_data ->> 'livemode'::text))::boolean) STORED,
    metadata jsonb GENERATED ALWAYS AS ((_raw_data -> 'metadata'::text)) STORED,
    evidence_details jsonb GENERATED ALWAYS AS ((_raw_data -> 'evidence_details'::text)) STORED,
    balance_transactions jsonb GENERATED ALWAYS AS ((_raw_data -> 'balance_transactions'::text)) STORED,
    is_charge_refundable boolean GENERATED ALWAYS AS (((_raw_data ->> 'is_charge_refundable'::text))::boolean) STORED,
    payment_intent text GENERATED ALWAYS AS ((_raw_data ->> 'payment_intent'::text)) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: early_fraud_warnings; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.early_fraud_warnings (
    _updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    _account_id text NOT NULL,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    actionable boolean GENERATED ALWAYS AS (((_raw_data ->> 'actionable'::text))::boolean) STORED,
    charge text GENERATED ALWAYS AS ((_raw_data ->> 'charge'::text)) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    fraud_type text GENERATED ALWAYS AS ((_raw_data ->> 'fraud_type'::text)) STORED,
    livemode boolean GENERATED ALWAYS AS (((_raw_data ->> 'livemode'::text))::boolean) STORED,
    payment_intent text GENERATED ALWAYS AS ((_raw_data ->> 'payment_intent'::text)) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: events; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.events (
    _updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    data jsonb GENERATED ALWAYS AS ((_raw_data -> 'data'::text)) STORED,
    type text GENERATED ALWAYS AS ((_raw_data ->> 'type'::text)) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    request text GENERATED ALWAYS AS ((_raw_data ->> 'request'::text)) STORED,
    updated integer GENERATED ALWAYS AS (((_raw_data ->> 'updated'::text))::integer) STORED,
    livemode boolean GENERATED ALWAYS AS (((_raw_data ->> 'livemode'::text))::boolean) STORED,
    api_version text GENERATED ALWAYS AS ((_raw_data ->> 'api_version'::text)) STORED,
    pending_webhooks bigint GENERATED ALWAYS AS (((_raw_data ->> 'pending_webhooks'::text))::bigint) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: features; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.features (
    _updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    _account_id text NOT NULL,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    livemode boolean GENERATED ALWAYS AS (((_raw_data ->> 'livemode'::text))::boolean) STORED,
    name text GENERATED ALWAYS AS ((_raw_data ->> 'name'::text)) STORED,
    lookup_key text GENERATED ALWAYS AS ((_raw_data ->> 'lookup_key'::text)) STORED,
    active boolean GENERATED ALWAYS AS (((_raw_data ->> 'active'::text))::boolean) STORED,
    metadata jsonb GENERATED ALWAYS AS ((_raw_data -> 'metadata'::text)) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: invoices; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.invoices (
    _updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    _account_id text NOT NULL,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    auto_advance boolean GENERATED ALWAYS AS (((_raw_data ->> 'auto_advance'::text))::boolean) STORED,
    collection_method text GENERATED ALWAYS AS ((_raw_data ->> 'collection_method'::text)) STORED,
    currency text GENERATED ALWAYS AS ((_raw_data ->> 'currency'::text)) STORED,
    description text GENERATED ALWAYS AS ((_raw_data ->> 'description'::text)) STORED,
    hosted_invoice_url text GENERATED ALWAYS AS ((_raw_data ->> 'hosted_invoice_url'::text)) STORED,
    lines jsonb GENERATED ALWAYS AS ((_raw_data -> 'lines'::text)) STORED,
    period_end integer GENERATED ALWAYS AS (((_raw_data ->> 'period_end'::text))::integer) STORED,
    period_start integer GENERATED ALWAYS AS (((_raw_data ->> 'period_start'::text))::integer) STORED,
    status text GENERATED ALWAYS AS ((_raw_data ->> 'status'::text)) STORED,
    total bigint GENERATED ALWAYS AS (((_raw_data ->> 'total'::text))::bigint) STORED,
    account_country text GENERATED ALWAYS AS ((_raw_data ->> 'account_country'::text)) STORED,
    account_name text GENERATED ALWAYS AS ((_raw_data ->> 'account_name'::text)) STORED,
    account_tax_ids jsonb GENERATED ALWAYS AS ((_raw_data -> 'account_tax_ids'::text)) STORED,
    amount_due bigint GENERATED ALWAYS AS (((_raw_data ->> 'amount_due'::text))::bigint) STORED,
    amount_paid bigint GENERATED ALWAYS AS (((_raw_data ->> 'amount_paid'::text))::bigint) STORED,
    amount_remaining bigint GENERATED ALWAYS AS (((_raw_data ->> 'amount_remaining'::text))::bigint) STORED,
    application_fee_amount bigint GENERATED ALWAYS AS (((_raw_data ->> 'application_fee_amount'::text))::bigint) STORED,
    attempt_count integer GENERATED ALWAYS AS (((_raw_data ->> 'attempt_count'::text))::integer) STORED,
    attempted boolean GENERATED ALWAYS AS (((_raw_data ->> 'attempted'::text))::boolean) STORED,
    billing_reason text GENERATED ALWAYS AS ((_raw_data ->> 'billing_reason'::text)) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    custom_fields jsonb GENERATED ALWAYS AS ((_raw_data -> 'custom_fields'::text)) STORED,
    customer_address jsonb GENERATED ALWAYS AS ((_raw_data -> 'customer_address'::text)) STORED,
    customer_email text GENERATED ALWAYS AS ((_raw_data ->> 'customer_email'::text)) STORED,
    customer_name text GENERATED ALWAYS AS ((_raw_data ->> 'customer_name'::text)) STORED,
    customer_phone text GENERATED ALWAYS AS ((_raw_data ->> 'customer_phone'::text)) STORED,
    customer_shipping jsonb GENERATED ALWAYS AS ((_raw_data -> 'customer_shipping'::text)) STORED,
    customer_tax_exempt text GENERATED ALWAYS AS ((_raw_data ->> 'customer_tax_exempt'::text)) STORED,
    customer_tax_ids jsonb GENERATED ALWAYS AS ((_raw_data -> 'customer_tax_ids'::text)) STORED,
    default_tax_rates jsonb GENERATED ALWAYS AS ((_raw_data -> 'default_tax_rates'::text)) STORED,
    discount jsonb GENERATED ALWAYS AS ((_raw_data -> 'discount'::text)) STORED,
    discounts jsonb GENERATED ALWAYS AS ((_raw_data -> 'discounts'::text)) STORED,
    due_date integer GENERATED ALWAYS AS (((_raw_data ->> 'due_date'::text))::integer) STORED,
    ending_balance integer GENERATED ALWAYS AS (((_raw_data ->> 'ending_balance'::text))::integer) STORED,
    footer text GENERATED ALWAYS AS ((_raw_data ->> 'footer'::text)) STORED,
    invoice_pdf text GENERATED ALWAYS AS ((_raw_data ->> 'invoice_pdf'::text)) STORED,
    last_finalization_error jsonb GENERATED ALWAYS AS ((_raw_data -> 'last_finalization_error'::text)) STORED,
    livemode boolean GENERATED ALWAYS AS (((_raw_data ->> 'livemode'::text))::boolean) STORED,
    next_payment_attempt integer GENERATED ALWAYS AS (((_raw_data ->> 'next_payment_attempt'::text))::integer) STORED,
    number text GENERATED ALWAYS AS ((_raw_data ->> 'number'::text)) STORED,
    paid boolean GENERATED ALWAYS AS (((_raw_data ->> 'paid'::text))::boolean) STORED,
    payment_settings jsonb GENERATED ALWAYS AS ((_raw_data -> 'payment_settings'::text)) STORED,
    post_payment_credit_notes_amount integer GENERATED ALWAYS AS (((_raw_data ->> 'post_payment_credit_notes_amount'::text))::integer) STORED,
    pre_payment_credit_notes_amount integer GENERATED ALWAYS AS (((_raw_data ->> 'pre_payment_credit_notes_amount'::text))::integer) STORED,
    receipt_number text GENERATED ALWAYS AS ((_raw_data ->> 'receipt_number'::text)) STORED,
    starting_balance integer GENERATED ALWAYS AS (((_raw_data ->> 'starting_balance'::text))::integer) STORED,
    statement_descriptor text GENERATED ALWAYS AS ((_raw_data ->> 'statement_descriptor'::text)) STORED,
    status_transitions jsonb GENERATED ALWAYS AS ((_raw_data -> 'status_transitions'::text)) STORED,
    subtotal integer GENERATED ALWAYS AS (((_raw_data ->> 'subtotal'::text))::integer) STORED,
    tax integer GENERATED ALWAYS AS (((_raw_data ->> 'tax'::text))::integer) STORED,
    total_discount_amounts jsonb GENERATED ALWAYS AS ((_raw_data -> 'total_discount_amounts'::text)) STORED,
    total_tax_amounts jsonb GENERATED ALWAYS AS ((_raw_data -> 'total_tax_amounts'::text)) STORED,
    transfer_data jsonb GENERATED ALWAYS AS ((_raw_data -> 'transfer_data'::text)) STORED,
    webhooks_delivered_at integer GENERATED ALWAYS AS (((_raw_data ->> 'webhooks_delivered_at'::text))::integer) STORED,
    customer text GENERATED ALWAYS AS ((_raw_data ->> 'customer'::text)) STORED,
    subscription text GENERATED ALWAYS AS ((_raw_data ->> 'subscription'::text)) STORED,
    payment_intent text GENERATED ALWAYS AS ((_raw_data ->> 'payment_intent'::text)) STORED,
    default_payment_method text GENERATED ALWAYS AS ((_raw_data ->> 'default_payment_method'::text)) STORED,
    default_source text GENERATED ALWAYS AS ((_raw_data ->> 'default_source'::text)) STORED,
    on_behalf_of text GENERATED ALWAYS AS ((_raw_data ->> 'on_behalf_of'::text)) STORED,
    charge text GENERATED ALWAYS AS ((_raw_data ->> 'charge'::text)) STORED,
    metadata jsonb GENERATED ALWAYS AS ((_raw_data -> 'metadata'::text)) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: payment_intents; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.payment_intents (
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    _account_id text NOT NULL,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    amount integer GENERATED ALWAYS AS (((_raw_data ->> 'amount'::text))::integer) STORED,
    amount_capturable integer GENERATED ALWAYS AS (((_raw_data ->> 'amount_capturable'::text))::integer) STORED,
    amount_details jsonb GENERATED ALWAYS AS ((_raw_data -> 'amount_details'::text)) STORED,
    amount_received integer GENERATED ALWAYS AS (((_raw_data ->> 'amount_received'::text))::integer) STORED,
    application text GENERATED ALWAYS AS ((_raw_data ->> 'application'::text)) STORED,
    application_fee_amount integer GENERATED ALWAYS AS (((_raw_data ->> 'application_fee_amount'::text))::integer) STORED,
    automatic_payment_methods text GENERATED ALWAYS AS ((_raw_data ->> 'automatic_payment_methods'::text)) STORED,
    canceled_at integer GENERATED ALWAYS AS (((_raw_data ->> 'canceled_at'::text))::integer) STORED,
    cancellation_reason text GENERATED ALWAYS AS ((_raw_data ->> 'cancellation_reason'::text)) STORED,
    capture_method text GENERATED ALWAYS AS ((_raw_data ->> 'capture_method'::text)) STORED,
    client_secret text GENERATED ALWAYS AS ((_raw_data ->> 'client_secret'::text)) STORED,
    confirmation_method text GENERATED ALWAYS AS ((_raw_data ->> 'confirmation_method'::text)) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    currency text GENERATED ALWAYS AS ((_raw_data ->> 'currency'::text)) STORED,
    customer text GENERATED ALWAYS AS ((_raw_data ->> 'customer'::text)) STORED,
    description text GENERATED ALWAYS AS ((_raw_data ->> 'description'::text)) STORED,
    invoice text GENERATED ALWAYS AS ((_raw_data ->> 'invoice'::text)) STORED,
    last_payment_error text GENERATED ALWAYS AS ((_raw_data ->> 'last_payment_error'::text)) STORED,
    livemode boolean GENERATED ALWAYS AS (((_raw_data ->> 'livemode'::text))::boolean) STORED,
    metadata jsonb GENERATED ALWAYS AS ((_raw_data -> 'metadata'::text)) STORED,
    next_action text GENERATED ALWAYS AS ((_raw_data ->> 'next_action'::text)) STORED,
    on_behalf_of text GENERATED ALWAYS AS ((_raw_data ->> 'on_behalf_of'::text)) STORED,
    payment_method text GENERATED ALWAYS AS ((_raw_data ->> 'payment_method'::text)) STORED,
    payment_method_options jsonb GENERATED ALWAYS AS ((_raw_data -> 'payment_method_options'::text)) STORED,
    payment_method_types jsonb GENERATED ALWAYS AS ((_raw_data -> 'payment_method_types'::text)) STORED,
    processing text GENERATED ALWAYS AS ((_raw_data ->> 'processing'::text)) STORED,
    receipt_email text GENERATED ALWAYS AS ((_raw_data ->> 'receipt_email'::text)) STORED,
    review text GENERATED ALWAYS AS ((_raw_data ->> 'review'::text)) STORED,
    setup_future_usage text GENERATED ALWAYS AS ((_raw_data ->> 'setup_future_usage'::text)) STORED,
    shipping jsonb GENERATED ALWAYS AS ((_raw_data -> 'shipping'::text)) STORED,
    statement_descriptor text GENERATED ALWAYS AS ((_raw_data ->> 'statement_descriptor'::text)) STORED,
    statement_descriptor_suffix text GENERATED ALWAYS AS ((_raw_data ->> 'statement_descriptor_suffix'::text)) STORED,
    status text GENERATED ALWAYS AS ((_raw_data ->> 'status'::text)) STORED,
    transfer_data jsonb GENERATED ALWAYS AS ((_raw_data -> 'transfer_data'::text)) STORED,
    transfer_group text GENERATED ALWAYS AS ((_raw_data ->> 'transfer_group'::text)) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: payment_methods; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.payment_methods (
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    _account_id text NOT NULL,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    customer text GENERATED ALWAYS AS ((_raw_data ->> 'customer'::text)) STORED,
    type text GENERATED ALWAYS AS ((_raw_data ->> 'type'::text)) STORED,
    billing_details jsonb GENERATED ALWAYS AS ((_raw_data -> 'billing_details'::text)) STORED,
    metadata jsonb GENERATED ALWAYS AS ((_raw_data -> 'metadata'::text)) STORED,
    card jsonb GENERATED ALWAYS AS ((_raw_data -> 'card'::text)) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: payouts; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.payouts (
    _updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    date text GENERATED ALWAYS AS ((_raw_data ->> 'date'::text)) STORED,
    type text GENERATED ALWAYS AS ((_raw_data ->> 'type'::text)) STORED,
    amount bigint GENERATED ALWAYS AS (((_raw_data ->> 'amount'::text))::bigint) STORED,
    method text GENERATED ALWAYS AS ((_raw_data ->> 'method'::text)) STORED,
    status text GENERATED ALWAYS AS ((_raw_data ->> 'status'::text)) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    updated integer GENERATED ALWAYS AS (((_raw_data ->> 'updated'::text))::integer) STORED,
    currency text GENERATED ALWAYS AS ((_raw_data ->> 'currency'::text)) STORED,
    livemode boolean GENERATED ALWAYS AS (((_raw_data ->> 'livemode'::text))::boolean) STORED,
    metadata jsonb GENERATED ALWAYS AS ((_raw_data -> 'metadata'::text)) STORED,
    automatic boolean GENERATED ALWAYS AS (((_raw_data ->> 'automatic'::text))::boolean) STORED,
    recipient text GENERATED ALWAYS AS ((_raw_data ->> 'recipient'::text)) STORED,
    description text GENERATED ALWAYS AS ((_raw_data ->> 'description'::text)) STORED,
    destination text GENERATED ALWAYS AS ((_raw_data ->> 'destination'::text)) STORED,
    source_type text GENERATED ALWAYS AS ((_raw_data ->> 'source_type'::text)) STORED,
    arrival_date text GENERATED ALWAYS AS ((_raw_data ->> 'arrival_date'::text)) STORED,
    bank_account jsonb GENERATED ALWAYS AS ((_raw_data -> 'bank_account'::text)) STORED,
    failure_code text GENERATED ALWAYS AS ((_raw_data ->> 'failure_code'::text)) STORED,
    transfer_group text GENERATED ALWAYS AS ((_raw_data ->> 'transfer_group'::text)) STORED,
    amount_reversed bigint GENERATED ALWAYS AS (((_raw_data ->> 'amount_reversed'::text))::bigint) STORED,
    failure_message text GENERATED ALWAYS AS ((_raw_data ->> 'failure_message'::text)) STORED,
    source_transaction text GENERATED ALWAYS AS ((_raw_data ->> 'source_transaction'::text)) STORED,
    balance_transaction text GENERATED ALWAYS AS ((_raw_data ->> 'balance_transaction'::text)) STORED,
    statement_descriptor text GENERATED ALWAYS AS ((_raw_data ->> 'statement_descriptor'::text)) STORED,
    statement_description text GENERATED ALWAYS AS ((_raw_data ->> 'statement_description'::text)) STORED,
    failure_balance_transaction text GENERATED ALWAYS AS ((_raw_data ->> 'failure_balance_transaction'::text)) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: plans; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.plans (
    _updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    _account_id text NOT NULL,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    name text GENERATED ALWAYS AS ((_raw_data ->> 'name'::text)) STORED,
    tiers jsonb GENERATED ALWAYS AS ((_raw_data -> 'tiers'::text)) STORED,
    active boolean GENERATED ALWAYS AS (((_raw_data ->> 'active'::text))::boolean) STORED,
    amount bigint GENERATED ALWAYS AS (((_raw_data ->> 'amount'::text))::bigint) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    product text GENERATED ALWAYS AS ((_raw_data ->> 'product'::text)) STORED,
    updated integer GENERATED ALWAYS AS (((_raw_data ->> 'updated'::text))::integer) STORED,
    currency text GENERATED ALWAYS AS ((_raw_data ->> 'currency'::text)) STORED,
    "interval" text GENERATED ALWAYS AS ((_raw_data ->> 'interval'::text)) STORED,
    livemode boolean GENERATED ALWAYS AS (((_raw_data ->> 'livemode'::text))::boolean) STORED,
    metadata jsonb GENERATED ALWAYS AS ((_raw_data -> 'metadata'::text)) STORED,
    nickname text GENERATED ALWAYS AS ((_raw_data ->> 'nickname'::text)) STORED,
    tiers_mode text GENERATED ALWAYS AS ((_raw_data ->> 'tiers_mode'::text)) STORED,
    usage_type text GENERATED ALWAYS AS ((_raw_data ->> 'usage_type'::text)) STORED,
    billing_scheme text GENERATED ALWAYS AS ((_raw_data ->> 'billing_scheme'::text)) STORED,
    interval_count bigint GENERATED ALWAYS AS (((_raw_data ->> 'interval_count'::text))::bigint) STORED,
    aggregate_usage text GENERATED ALWAYS AS ((_raw_data ->> 'aggregate_usage'::text)) STORED,
    transform_usage text GENERATED ALWAYS AS ((_raw_data ->> 'transform_usage'::text)) STORED,
    trial_period_days bigint GENERATED ALWAYS AS (((_raw_data ->> 'trial_period_days'::text))::bigint) STORED,
    statement_descriptor text GENERATED ALWAYS AS ((_raw_data ->> 'statement_descriptor'::text)) STORED,
    statement_description text GENERATED ALWAYS AS ((_raw_data ->> 'statement_description'::text)) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: prices; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.prices (
    _updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    _account_id text NOT NULL,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    active boolean GENERATED ALWAYS AS (((_raw_data ->> 'active'::text))::boolean) STORED,
    currency text GENERATED ALWAYS AS ((_raw_data ->> 'currency'::text)) STORED,
    metadata jsonb GENERATED ALWAYS AS ((_raw_data -> 'metadata'::text)) STORED,
    nickname text GENERATED ALWAYS AS ((_raw_data ->> 'nickname'::text)) STORED,
    recurring jsonb GENERATED ALWAYS AS ((_raw_data -> 'recurring'::text)) STORED,
    type text GENERATED ALWAYS AS ((_raw_data ->> 'type'::text)) STORED,
    unit_amount integer GENERATED ALWAYS AS (((_raw_data ->> 'unit_amount'::text))::integer) STORED,
    billing_scheme text GENERATED ALWAYS AS ((_raw_data ->> 'billing_scheme'::text)) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    livemode boolean GENERATED ALWAYS AS (((_raw_data ->> 'livemode'::text))::boolean) STORED,
    lookup_key text GENERATED ALWAYS AS ((_raw_data ->> 'lookup_key'::text)) STORED,
    tiers_mode text GENERATED ALWAYS AS ((_raw_data ->> 'tiers_mode'::text)) STORED,
    transform_quantity jsonb GENERATED ALWAYS AS ((_raw_data -> 'transform_quantity'::text)) STORED,
    unit_amount_decimal text GENERATED ALWAYS AS ((_raw_data ->> 'unit_amount_decimal'::text)) STORED,
    product text GENERATED ALWAYS AS ((_raw_data ->> 'product'::text)) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: products; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.products (
    _updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    _account_id text NOT NULL,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    active boolean GENERATED ALWAYS AS (((_raw_data ->> 'active'::text))::boolean) STORED,
    default_price text GENERATED ALWAYS AS ((_raw_data ->> 'default_price'::text)) STORED,
    description text GENERATED ALWAYS AS ((_raw_data ->> 'description'::text)) STORED,
    metadata jsonb GENERATED ALWAYS AS ((_raw_data -> 'metadata'::text)) STORED,
    name text GENERATED ALWAYS AS ((_raw_data ->> 'name'::text)) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    images jsonb GENERATED ALWAYS AS ((_raw_data -> 'images'::text)) STORED,
    marketing_features jsonb GENERATED ALWAYS AS ((_raw_data -> 'marketing_features'::text)) STORED,
    livemode boolean GENERATED ALWAYS AS (((_raw_data ->> 'livemode'::text))::boolean) STORED,
    package_dimensions jsonb GENERATED ALWAYS AS ((_raw_data -> 'package_dimensions'::text)) STORED,
    shippable boolean GENERATED ALWAYS AS (((_raw_data ->> 'shippable'::text))::boolean) STORED,
    statement_descriptor text GENERATED ALWAYS AS ((_raw_data ->> 'statement_descriptor'::text)) STORED,
    unit_label text GENERATED ALWAYS AS ((_raw_data ->> 'unit_label'::text)) STORED,
    updated integer GENERATED ALWAYS AS (((_raw_data ->> 'updated'::text))::integer) STORED,
    url text GENERATED ALWAYS AS ((_raw_data ->> 'url'::text)) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: refunds; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.refunds (
    _updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    _account_id text NOT NULL,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    amount integer GENERATED ALWAYS AS (((_raw_data ->> 'amount'::text))::integer) STORED,
    balance_transaction text GENERATED ALWAYS AS ((_raw_data ->> 'balance_transaction'::text)) STORED,
    charge text GENERATED ALWAYS AS ((_raw_data ->> 'charge'::text)) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    currency text GENERATED ALWAYS AS ((_raw_data ->> 'currency'::text)) STORED,
    destination_details jsonb GENERATED ALWAYS AS ((_raw_data -> 'destination_details'::text)) STORED,
    metadata jsonb GENERATED ALWAYS AS ((_raw_data -> 'metadata'::text)) STORED,
    payment_intent text GENERATED ALWAYS AS ((_raw_data ->> 'payment_intent'::text)) STORED,
    reason text GENERATED ALWAYS AS ((_raw_data ->> 'reason'::text)) STORED,
    receipt_number text GENERATED ALWAYS AS ((_raw_data ->> 'receipt_number'::text)) STORED,
    source_transfer_reversal text GENERATED ALWAYS AS ((_raw_data ->> 'source_transfer_reversal'::text)) STORED,
    status text GENERATED ALWAYS AS ((_raw_data ->> 'status'::text)) STORED,
    transfer_reversal text GENERATED ALWAYS AS ((_raw_data ->> 'transfer_reversal'::text)) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: reviews; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.reviews (
    _updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    _account_id text NOT NULL,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    billing_zip text GENERATED ALWAYS AS ((_raw_data ->> 'billing_zip'::text)) STORED,
    charge text GENERATED ALWAYS AS ((_raw_data ->> 'charge'::text)) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    closed_reason text GENERATED ALWAYS AS ((_raw_data ->> 'closed_reason'::text)) STORED,
    livemode boolean GENERATED ALWAYS AS (((_raw_data ->> 'livemode'::text))::boolean) STORED,
    ip_address text GENERATED ALWAYS AS ((_raw_data ->> 'ip_address'::text)) STORED,
    ip_address_location jsonb GENERATED ALWAYS AS ((_raw_data -> 'ip_address_location'::text)) STORED,
    open boolean GENERATED ALWAYS AS (((_raw_data ->> 'open'::text))::boolean) STORED,
    opened_reason text GENERATED ALWAYS AS ((_raw_data ->> 'opened_reason'::text)) STORED,
    payment_intent text GENERATED ALWAYS AS ((_raw_data ->> 'payment_intent'::text)) STORED,
    reason text GENERATED ALWAYS AS ((_raw_data ->> 'reason'::text)) STORED,
    session text GENERATED ALWAYS AS ((_raw_data ->> 'session'::text)) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: setup_intents; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.setup_intents (
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    _account_id text NOT NULL,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    customer text GENERATED ALWAYS AS ((_raw_data ->> 'customer'::text)) STORED,
    description text GENERATED ALWAYS AS ((_raw_data ->> 'description'::text)) STORED,
    payment_method text GENERATED ALWAYS AS ((_raw_data ->> 'payment_method'::text)) STORED,
    status text GENERATED ALWAYS AS ((_raw_data ->> 'status'::text)) STORED,
    usage text GENERATED ALWAYS AS ((_raw_data ->> 'usage'::text)) STORED,
    cancellation_reason text GENERATED ALWAYS AS ((_raw_data ->> 'cancellation_reason'::text)) STORED,
    latest_attempt text GENERATED ALWAYS AS ((_raw_data ->> 'latest_attempt'::text)) STORED,
    mandate text GENERATED ALWAYS AS ((_raw_data ->> 'mandate'::text)) STORED,
    single_use_mandate text GENERATED ALWAYS AS ((_raw_data ->> 'single_use_mandate'::text)) STORED,
    on_behalf_of text GENERATED ALWAYS AS ((_raw_data ->> 'on_behalf_of'::text)) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: subscription_items; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.subscription_items (
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    _account_id text NOT NULL,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    billing_thresholds jsonb GENERATED ALWAYS AS ((_raw_data -> 'billing_thresholds'::text)) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    deleted boolean GENERATED ALWAYS AS (((_raw_data ->> 'deleted'::text))::boolean) STORED,
    metadata jsonb GENERATED ALWAYS AS ((_raw_data -> 'metadata'::text)) STORED,
    quantity integer GENERATED ALWAYS AS (((_raw_data ->> 'quantity'::text))::integer) STORED,
    price text GENERATED ALWAYS AS ((_raw_data ->> 'price'::text)) STORED,
    subscription text GENERATED ALWAYS AS ((_raw_data ->> 'subscription'::text)) STORED,
    tax_rates jsonb GENERATED ALWAYS AS ((_raw_data -> 'tax_rates'::text)) STORED,
    current_period_end integer GENERATED ALWAYS AS (((_raw_data ->> 'current_period_end'::text))::integer) STORED,
    current_period_start integer GENERATED ALWAYS AS (((_raw_data ->> 'current_period_start'::text))::integer) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: subscription_schedules; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.subscription_schedules (
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    _account_id text NOT NULL,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    application text GENERATED ALWAYS AS ((_raw_data ->> 'application'::text)) STORED,
    canceled_at integer GENERATED ALWAYS AS (((_raw_data ->> 'canceled_at'::text))::integer) STORED,
    completed_at integer GENERATED ALWAYS AS (((_raw_data ->> 'completed_at'::text))::integer) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    current_phase jsonb GENERATED ALWAYS AS ((_raw_data -> 'current_phase'::text)) STORED,
    customer text GENERATED ALWAYS AS ((_raw_data ->> 'customer'::text)) STORED,
    default_settings jsonb GENERATED ALWAYS AS ((_raw_data -> 'default_settings'::text)) STORED,
    end_behavior text GENERATED ALWAYS AS ((_raw_data ->> 'end_behavior'::text)) STORED,
    livemode boolean GENERATED ALWAYS AS (((_raw_data ->> 'livemode'::text))::boolean) STORED,
    metadata jsonb GENERATED ALWAYS AS ((_raw_data -> 'metadata'::text)) STORED,
    phases jsonb GENERATED ALWAYS AS ((_raw_data -> 'phases'::text)) STORED,
    released_at integer GENERATED ALWAYS AS (((_raw_data ->> 'released_at'::text))::integer) STORED,
    released_subscription text GENERATED ALWAYS AS ((_raw_data ->> 'released_subscription'::text)) STORED,
    status text GENERATED ALWAYS AS ((_raw_data ->> 'status'::text)) STORED,
    subscription text GENERATED ALWAYS AS ((_raw_data ->> 'subscription'::text)) STORED,
    test_clock text GENERATED ALWAYS AS ((_raw_data ->> 'test_clock'::text)) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: subscriptions; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.subscriptions (
    _updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    _account_id text NOT NULL,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    cancel_at_period_end boolean GENERATED ALWAYS AS (((_raw_data ->> 'cancel_at_period_end'::text))::boolean) STORED,
    current_period_end integer GENERATED ALWAYS AS (((_raw_data ->> 'current_period_end'::text))::integer) STORED,
    current_period_start integer GENERATED ALWAYS AS (((_raw_data ->> 'current_period_start'::text))::integer) STORED,
    default_payment_method text GENERATED ALWAYS AS ((_raw_data ->> 'default_payment_method'::text)) STORED,
    items jsonb GENERATED ALWAYS AS ((_raw_data -> 'items'::text)) STORED,
    metadata jsonb GENERATED ALWAYS AS ((_raw_data -> 'metadata'::text)) STORED,
    pending_setup_intent text GENERATED ALWAYS AS ((_raw_data ->> 'pending_setup_intent'::text)) STORED,
    pending_update jsonb GENERATED ALWAYS AS ((_raw_data -> 'pending_update'::text)) STORED,
    status text GENERATED ALWAYS AS ((_raw_data ->> 'status'::text)) STORED,
    application_fee_percent double precision GENERATED ALWAYS AS (((_raw_data ->> 'application_fee_percent'::text))::double precision) STORED,
    billing_cycle_anchor integer GENERATED ALWAYS AS (((_raw_data ->> 'billing_cycle_anchor'::text))::integer) STORED,
    billing_thresholds jsonb GENERATED ALWAYS AS ((_raw_data -> 'billing_thresholds'::text)) STORED,
    cancel_at integer GENERATED ALWAYS AS (((_raw_data ->> 'cancel_at'::text))::integer) STORED,
    canceled_at integer GENERATED ALWAYS AS (((_raw_data ->> 'canceled_at'::text))::integer) STORED,
    collection_method text GENERATED ALWAYS AS ((_raw_data ->> 'collection_method'::text)) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    days_until_due integer GENERATED ALWAYS AS (((_raw_data ->> 'days_until_due'::text))::integer) STORED,
    default_source text GENERATED ALWAYS AS ((_raw_data ->> 'default_source'::text)) STORED,
    default_tax_rates jsonb GENERATED ALWAYS AS ((_raw_data -> 'default_tax_rates'::text)) STORED,
    discount jsonb GENERATED ALWAYS AS ((_raw_data -> 'discount'::text)) STORED,
    ended_at integer GENERATED ALWAYS AS (((_raw_data ->> 'ended_at'::text))::integer) STORED,
    livemode boolean GENERATED ALWAYS AS (((_raw_data ->> 'livemode'::text))::boolean) STORED,
    next_pending_invoice_item_invoice integer GENERATED ALWAYS AS (((_raw_data ->> 'next_pending_invoice_item_invoice'::text))::integer) STORED,
    pause_collection jsonb GENERATED ALWAYS AS ((_raw_data -> 'pause_collection'::text)) STORED,
    pending_invoice_item_interval jsonb GENERATED ALWAYS AS ((_raw_data -> 'pending_invoice_item_interval'::text)) STORED,
    start_date integer GENERATED ALWAYS AS (((_raw_data ->> 'start_date'::text))::integer) STORED,
    transfer_data jsonb GENERATED ALWAYS AS ((_raw_data -> 'transfer_data'::text)) STORED,
    trial_end jsonb GENERATED ALWAYS AS ((_raw_data -> 'trial_end'::text)) STORED,
    trial_start jsonb GENERATED ALWAYS AS ((_raw_data -> 'trial_start'::text)) STORED,
    schedule text GENERATED ALWAYS AS ((_raw_data ->> 'schedule'::text)) STORED,
    customer text GENERATED ALWAYS AS ((_raw_data ->> 'customer'::text)) STORED,
    latest_invoice text GENERATED ALWAYS AS ((_raw_data ->> 'latest_invoice'::text)) STORED,
    plan text GENERATED ALWAYS AS ((_raw_data ->> 'plan'::text)) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: tax_ids; Type: TABLE; Schema: stripe; Owner: -
--

CREATE TABLE stripe.tax_ids (
    _last_synced_at timestamp with time zone,
    _raw_data jsonb,
    _account_id text NOT NULL,
    object text GENERATED ALWAYS AS ((_raw_data ->> 'object'::text)) STORED,
    country text GENERATED ALWAYS AS ((_raw_data ->> 'country'::text)) STORED,
    customer text GENERATED ALWAYS AS ((_raw_data ->> 'customer'::text)) STORED,
    type text GENERATED ALWAYS AS ((_raw_data ->> 'type'::text)) STORED,
    value text GENERATED ALWAYS AS ((_raw_data ->> 'value'::text)) STORED,
    created integer GENERATED ALWAYS AS (((_raw_data ->> 'created'::text))::integer) STORED,
    livemode boolean GENERATED ALWAYS AS (((_raw_data ->> 'livemode'::text))::boolean) STORED,
    owner jsonb GENERATED ALWAYS AS ((_raw_data -> 'owner'::text)) STORED,
    id text GENERATED ALWAYS AS ((_raw_data ->> 'id'::text)) STORED NOT NULL
);


--
-- Name: cart_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_items ALTER COLUMN id SET DEFAULT nextval('public.cart_items_id_seq'::regclass);


--
-- Name: email_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs ALTER COLUMN id SET DEFAULT nextval('public.email_logs_id_seq'::regclass);


--
-- Name: monetizze_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monetizze_orders ALTER COLUMN id SET DEFAULT nextval('public.monetizze_orders_id_seq'::regclass);


--
-- Name: payment_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_orders ALTER COLUMN id SET DEFAULT nextval('public.payment_orders_id_seq'::regclass);


--
-- Name: platform_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_settings ALTER COLUMN id SET DEFAULT nextval('public.platform_settings_id_seq'::regclass);


--
-- Name: processed_payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.processed_payments ALTER COLUMN id SET DEFAULT nextval('public.processed_payments_id_seq'::regclass);


--
-- Name: product_materials id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_materials ALTER COLUMN id SET DEFAULT nextval('public.product_materials_id_seq'::regclass);


--
-- Name: quote_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_history ALTER COLUMN id SET DEFAULT nextval('public.quote_history_id_seq'::regclass);


--
-- Name: shipments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipments ALTER COLUMN id SET DEFAULT nextval('public.shipments_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: whatsapp_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_messages ALTER COLUMN id SET DEFAULT nextval('public.whatsapp_messages_id_seq'::regclass);


--
-- Name: _sync_status id; Type: DEFAULT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe._sync_status ALTER COLUMN id SET DEFAULT nextval('stripe._sync_status_id_seq'::regclass);


--
-- Data for Name: cart_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cart_items (id, user_id, recipient_name, recipient_phone, recipient_cpf_cnpj, address, carrier, original_price, final_price, delivery_time, origin_zip, dest_zip, created_at, content_declaration, invoice_number, weight, height, width, length, sender_full_address, service_code, carrier_code, declared_value, sender_cpf_cnpj, volumes) FROM stdin;
16	33	João Teste	11999999999	52998224725	Rua Teste, 100	Correios - PAC	19.39	25.21	5	01310100	04543000	2026-04-22 19:57:46.525266	Teste 3 vol		1.00	10.00	10.00	15.00	Rua A, 1	03298	COR	\N	52998224725	3
17	33	Carlos	11988887777	52998224725	Av Brasil, 200	Correios - PAC	24.17	31.42	5	01310100	04543000	2026-04-22 20:02:39.9057	4 vols		1.00	10.00	10.00	15.00		03298	COR	\N		4
\.


--
-- Data for Name: email_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_logs (id, to_address, from_address, subject, html, text_body, status, provider, provider_message_id, error_message, context, related_user_id, related_shipment_id, related_monetizze_order_id, created_at) FROM stdin;
1	prosperidadeautomatica@gmail.com	Mais Natture LTDA via Despache Fácil <envios@despachefacil.com>	💳 Pagamento confirmado — Cápsulas Detox Natural Premium 60 unid já foi enviado!	<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>\n<body style="margin:0;padding:0;background:#f4f4f5;font-family:Arial,sans-serif">\n<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f5;padding:40px 0"><tr><td align="center">\n<table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08)">\n  <tr><td style="background:#0B3C5D;padding:28px;text-align:center">\n    <h1 style="margin:0;color:#ffffff;font-size:24px;font-weight:bold">Despache Fácil</h1>\n    <p style="margin:6px 0 0;color:rgba(255,255,255,0.85);font-size:14px">Pedido enviado</p>\n  </td></tr>\n  <tr><td style="padding:36px 40px">\n    <p style="margin:0 0 18px;color:#111827;font-size:20px;font-weight:bold;text-align:center">\n      💳 Pagamento confirmado com sucesso!\n    </p>\n    <p style="margin:0 0 22px;color:#374151;font-size:15px;line-height:1.6">\n      Olá, Maria Silva (TESTE)! Seu pagamento foi confirmado pela <strong>Monetizze</strong> e seu pedido já foi <strong>enviado e despachado</strong> pela <strong>Despache Fácil</strong>, em nome de <strong>Mais Natture LTDA</strong>.\n    </p>\n\n    <div style="background:#f0fdf4;border:2px solid #00C853;border-radius:10px;padding:18px 20px;margin:0 0 22px;text-align:center">\n      <div style="color:#065f46;font-size:13px;font-weight:600;letter-spacing:0.5px;margin-bottom:6px">📦 PRODUTO</div>\n      <div style="color:#064e3b;font-size:20px;font-weight:bold;line-height:1.3;text-transform:uppercase">CÁPSULAS DETOX NATURAL PREMIUM 60 UNID</div>\n    </div>\n\n    <table width="100%" cellpadding="0" cellspacing="0" style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:8px;margin:0 0 22px">\n      <tr><td style="padding:12px 18px;color:#6b7280;font-size:14px">Quantidade de itens</td><td style="padding:12px 18px;text-align:right;color:#111827;font-size:14px;font-weight:600">2</td></tr>\n      <tr><td style="padding:12px 18px;color:#6b7280;font-size:14px;border-top:1px solid #e5e7eb">Valor total do pedido</td><td style="padding:12px 18px;text-align:right;color:#111827;font-size:14px;font-weight:600;border-top:1px solid #e5e7eb">R$ 197,80</td></tr>\n      <tr><td style="padding:12px 18px;color:#6b7280;font-size:14px;border-top:1px solid #e5e7eb">Transportadora</td><td style="padding:12px 18px;text-align:right;color:#111827;font-size:14px;font-weight:600;border-top:1px solid #e5e7eb">Correios PAC</td></tr>\n      <tr><td style="padding:14px 18px;color:#00C853;font-size:14px;font-weight:bold;border-top:1px solid #e5e7eb">Código de rastreio</td><td style="padding:14px 18px;text-align:right;color:#0B3C5D;font-size:18px;font-weight:bold;border-top:1px solid #e5e7eb;font-family:monospace">OE123456789BR</td></tr>\n    </table>\n\n    <p style="margin:0 0 16px;color:#111827;font-size:15px;line-height:1.6">\n      ⏱️ <strong>Previsão de entrega:</strong> 7 dias úteis\n    </p>\n\n    <div style="background:#fffbeb;border-left:4px solid #f59e0b;border-radius:4px;padding:12px 16px;margin:0 0 22px">\n      <p style="margin:0;color:#92400e;font-size:13px;line-height:1.5">\n        ℹ️ O código de rastreio pode levar até <strong>24h</strong> para começar a mostrar atualizações.\n      </p>\n    </div>\n\n    <p style="margin:0 0 22px;color:#374151;font-size:14px;line-height:1.6">\n      Seu pedido foi <strong>processado, embalado e enviado com segurança</strong> pela Despache Fácil, responsável pela logística da Mais Natture LTDA.\n    </p>\n\n    <div style="background:#0B3C5D;border-radius:10px;padding:20px;text-align:center;margin:0 0 22px">\n      <p style="margin:0 0 12px;color:#ffffff;font-size:14px;line-height:1.5">\n        Quer enviar seus produtos com <strong>automação e praticidade</strong>?\n      </p>\n      <a href="https://despachefacil.com" style="display:inline-block;background:#00C853;color:#ffffff;text-decoration:none;padding:11px 24px;border-radius:6px;font-weight:bold;font-size:14px">🌐 Conheça a Despache Fácil</a>\n    </div>\n\n    <div style="text-align:center;border-top:1px solid #e5e7eb;padding-top:18px;margin-top:8px">\n      <p style="margin:0 0 4px;color:#111827;font-size:15px;font-weight:bold">Mais Natture LTDA</p>\n      <p style="margin:0;color:#6b7280;font-size:12px">Logística operada por Despache Fácil</p>\n    </div></td></tr>\n  <tr><td style="background:#f9fafb;padding:18px 40px;text-align:center;border-top:1px solid #e5e7eb">\n    <p style="margin:0;color:#9ca3af;font-size:12px">&copy; 2026 Despache Fácil. Em caso de dúvida, responda este e-mail.</p>\n  </td></tr>\n</table></td></tr></table></body></html>	💳 Pagamento confirmado com sucesso!\nOlá, Maria Silva (TESTE)!\nSeu pagamento foi confirmado pela Monetizze e seu pedido já foi enviado pela Despache Fácil em nome de Mais Natture LTDA.\n📦 PRODUTO: CÁPSULAS DETOX NATURAL PREMIUM 60 UNID\nQuantidade: 2\nValor total: R$ 197,80\nTransportadora: Correios PAC\nCódigo de rastreio: OE123456789BR\n⏱️ Previsão de entrega: 7 dias úteis\nO código de rastreio pode levar até 24h para começar a mostrar atualizações.\nSeu pedido foi processado, embalado e enviado com segurança pela Despache Fácil, responsável pela logística da Mais Natture LTDA.\nSe você também deseja enviar seus produtos com automação e praticidade, acesse:\n🌐 https://despachefacil.com\nMais Natture LTDA\nLogística operada por Despache Fácil	failed	resend	\N	API key is invalid	manual-test-preview	\N	\N	\N	2026-04-30 21:59:54.880093
2	prosperidadeautomatica@gmail.com	Mais Natture LTDA via Despache Fácil <envios@despachefacil.com>	💳 Pagamento confirmado — Cápsulas Detox Natural Premium 60 unid já foi enviado!	<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>\n<body style="margin:0;padding:0;background:#f4f4f5;font-family:Arial,sans-serif">\n<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f5;padding:40px 0"><tr><td align="center">\n<table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08)">\n  <tr><td style="background:#0B3C5D;padding:28px;text-align:center">\n    <h1 style="margin:0;color:#ffffff;font-size:24px;font-weight:bold">Despache Fácil</h1>\n    <p style="margin:6px 0 0;color:rgba(255,255,255,0.85);font-size:14px">Pedido enviado</p>\n  </td></tr>\n  <tr><td style="padding:36px 40px">\n    <p style="margin:0 0 18px;color:#111827;font-size:20px;font-weight:bold;text-align:center">\n      💳 Pagamento confirmado com sucesso!\n    </p>\n    <p style="margin:0 0 22px;color:#374151;font-size:15px;line-height:1.6">\n      Olá, Maria Silva (TESTE)! Seu pagamento foi confirmado pela <strong>Monetizze</strong> e seu pedido já foi <strong>enviado e despachado</strong> pela <strong>Despache Fácil</strong>, em nome de <strong>Mais Natture LTDA</strong>.\n    </p>\n\n    <div style="background:#f0fdf4;border:2px solid #00C853;border-radius:10px;padding:18px 20px;margin:0 0 22px;text-align:center">\n      <div style="color:#065f46;font-size:13px;font-weight:600;letter-spacing:0.5px;margin-bottom:6px">📦 PRODUTO</div>\n      <div style="color:#064e3b;font-size:20px;font-weight:bold;line-height:1.3;text-transform:uppercase">CÁPSULAS DETOX NATURAL PREMIUM 60 UNID</div>\n    </div>\n\n    <table width="100%" cellpadding="0" cellspacing="0" style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:8px;margin:0 0 22px">\n      <tr><td style="padding:12px 18px;color:#6b7280;font-size:14px">Quantidade de itens</td><td style="padding:12px 18px;text-align:right;color:#111827;font-size:14px;font-weight:600">2</td></tr>\n      <tr><td style="padding:12px 18px;color:#6b7280;font-size:14px;border-top:1px solid #e5e7eb">Valor total do pedido</td><td style="padding:12px 18px;text-align:right;color:#111827;font-size:14px;font-weight:600;border-top:1px solid #e5e7eb">R$ 197,80</td></tr>\n      <tr><td style="padding:12px 18px;color:#6b7280;font-size:14px;border-top:1px solid #e5e7eb">Transportadora</td><td style="padding:12px 18px;text-align:right;color:#111827;font-size:14px;font-weight:600;border-top:1px solid #e5e7eb">Correios PAC</td></tr>\n      <tr><td style="padding:14px 18px;color:#00C853;font-size:14px;font-weight:bold;border-top:1px solid #e5e7eb">Código de rastreio</td><td style="padding:14px 18px;text-align:right;color:#0B3C5D;font-size:18px;font-weight:bold;border-top:1px solid #e5e7eb;font-family:monospace">OE123456789BR</td></tr>\n    </table>\n\n    <p style="margin:0 0 16px;color:#111827;font-size:15px;line-height:1.6">\n      ⏱️ <strong>Previsão de entrega:</strong> 7 dias úteis\n    </p>\n\n    <div style="background:#fffbeb;border-left:4px solid #f59e0b;border-radius:4px;padding:12px 16px;margin:0 0 22px">\n      <p style="margin:0;color:#92400e;font-size:13px;line-height:1.5">\n        ℹ️ O código de rastreio pode levar até <strong>24h</strong> para começar a mostrar atualizações.\n      </p>\n    </div>\n\n    <p style="margin:0 0 22px;color:#374151;font-size:14px;line-height:1.6">\n      Seu pedido foi <strong>processado, embalado e enviado com segurança</strong> pela Despache Fácil, responsável pela logística da Mais Natture LTDA.\n    </p>\n\n    <div style="background:#0B3C5D;border-radius:10px;padding:20px;text-align:center;margin:0 0 22px">\n      <p style="margin:0 0 12px;color:#ffffff;font-size:14px;line-height:1.5">\n        Quer enviar seus produtos com <strong>automação e praticidade</strong>?\n      </p>\n      <a href="https://despachefacil.com" style="display:inline-block;background:#00C853;color:#ffffff;text-decoration:none;padding:11px 24px;border-radius:6px;font-weight:bold;font-size:14px">🌐 Conheça a Despache Fácil</a>\n    </div>\n\n    <div style="text-align:center;border-top:1px solid #e5e7eb;padding-top:18px;margin-top:8px">\n      <p style="margin:0 0 4px;color:#111827;font-size:15px;font-weight:bold">Mais Natture LTDA</p>\n      <p style="margin:0;color:#6b7280;font-size:12px">Logística operada por Despache Fácil</p>\n    </div></td></tr>\n  <tr><td style="background:#f9fafb;padding:18px 40px;text-align:center;border-top:1px solid #e5e7eb">\n    <p style="margin:0;color:#9ca3af;font-size:12px">&copy; 2026 Despache Fácil. Em caso de dúvida, responda este e-mail.</p>\n  </td></tr>\n</table></td></tr></table></body></html>	💳 Pagamento confirmado com sucesso!\nOlá, Maria Silva (TESTE)!\nSeu pagamento foi confirmado pela Monetizze e seu pedido já foi enviado pela Despache Fácil em nome de Mais Natture LTDA.\n📦 PRODUTO: CÁPSULAS DETOX NATURAL PREMIUM 60 UNID\nQuantidade: 2\nValor total: R$ 197,80\nTransportadora: Correios PAC\nCódigo de rastreio: OE123456789BR\n⏱️ Previsão de entrega: 7 dias úteis\nO código de rastreio pode levar até 24h para começar a mostrar atualizações.\nSeu pedido foi processado, embalado e enviado com segurança pela Despache Fácil, responsável pela logística da Mais Natture LTDA.\nSe você também deseja enviar seus produtos com automação e praticidade, acesse:\n🌐 https://despachefacil.com\nMais Natture LTDA\nLogística operada por Despache Fácil	sent	resend	d626e6e0-9f6e-4dff-b096-dcbd44a7ed3d	\N	manual-test-preview	\N	\N	\N	2026-04-30 22:02:10.688502
3	maria.silva@example.com	Cliente Teste via Despache Fácil <envios@despachefacil.com>	💳 Pagamento confirmado — kit Restart Intestinal já foi enviado!	<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>\n<body style="margin:0;padding:0;background:#f4f4f5;font-family:Arial,sans-serif">\n<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f5;padding:40px 0"><tr><td align="center">\n<table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08)">\n  <tr><td style="background:#0B3C5D;padding:28px;text-align:center">\n    <h1 style="margin:0;color:#ffffff;font-size:24px;font-weight:bold">Despache Fácil</h1>\n    <p style="margin:6px 0 0;color:rgba(255,255,255,0.85);font-size:14px">Pedido enviado</p>\n  </td></tr>\n  <tr><td style="padding:36px 40px">\n    <p style="margin:0 0 18px;color:#111827;font-size:20px;font-weight:bold;text-align:center">\n      💳 Pagamento confirmado com sucesso!\n    </p>\n    <p style="margin:0 0 22px;color:#374151;font-size:15px;line-height:1.6">\n      Olá, Maria Silva! Seu pagamento foi confirmado pela <strong>Monetizze</strong> e seu pedido já foi <strong>enviado e despachado</strong> pela <strong>Despache Fácil</strong>, em nome de <strong>Cliente Teste</strong>.\n    </p>\n\n    <div style="background:#f0fdf4;border:2px solid #00C853;border-radius:10px;padding:18px 20px;margin:0 0 22px;text-align:center">\n      <div style="color:#065f46;font-size:13px;font-weight:600;letter-spacing:0.5px;margin-bottom:6px">📦 PRODUTO</div>\n      <div style="color:#064e3b;font-size:20px;font-weight:bold;line-height:1.3;text-transform:uppercase">KIT RESTART INTESTINAL</div>\n    </div>\n\n    <table width="100%" cellpadding="0" cellspacing="0" style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:8px;margin:0 0 22px">\n      <tr><td style="padding:12px 18px;color:#6b7280;font-size:14px">Quantidade de itens</td><td style="padding:12px 18px;text-align:right;color:#111827;font-size:14px;font-weight:600">1</td></tr>\n      <tr><td style="padding:12px 18px;color:#6b7280;font-size:14px;border-top:1px solid #e5e7eb">Valor total do pedido</td><td style="padding:12px 18px;text-align:right;color:#111827;font-size:14px;font-weight:600;border-top:1px solid #e5e7eb">R$ 147,00</td></tr>\n      <tr><td style="padding:12px 18px;color:#6b7280;font-size:14px;border-top:1px solid #e5e7eb">Transportadora</td><td style="padding:12px 18px;text-align:right;color:#111827;font-size:14px;font-weight:600;border-top:1px solid #e5e7eb">Correios - Sedex</td></tr>\n      <tr><td style="padding:14px 18px;color:#00C853;font-size:14px;font-weight:bold;border-top:1px solid #e5e7eb">Código de rastreio</td><td style="padding:14px 18px;text-align:right;color:#0B3C5D;font-size:18px;font-weight:bold;border-top:1px solid #e5e7eb;font-family:monospace">AD391354255BR</td></tr>\n    </table>\n\n    <p style="margin:0 0 16px;color:#111827;font-size:15px;line-height:1.6">\n      ⏱️ <strong>Previsão de entrega:</strong> 1 dias úteis\n    </p>\n\n    <div style="background:#fffbeb;border-left:4px solid #f59e0b;border-radius:4px;padding:12px 16px;margin:0 0 22px">\n      <p style="margin:0;color:#92400e;font-size:13px;line-height:1.5">\n        ℹ️ O código de rastreio pode levar até <strong>24h</strong> para começar a mostrar atualizações.\n      </p>\n    </div>\n\n    <p style="margin:0 0 22px;color:#374151;font-size:14px;line-height:1.6">\n      Seu pedido foi <strong>processado, embalado e enviado com segurança</strong> pela Despache Fácil, responsável pela logística da Cliente Teste.\n    </p>\n\n    <div style="background:#0B3C5D;border-radius:10px;padding:20px;text-align:center;margin:0 0 22px">\n      <p style="margin:0 0 12px;color:#ffffff;font-size:14px;line-height:1.5">\n        Quer enviar seus produtos com <strong>automação e praticidade</strong>?\n      </p>\n      <a href="https://despachefacil.com" style="display:inline-block;background:#00C853;color:#ffffff;text-decoration:none;padding:11px 24px;border-radius:6px;font-weight:bold;font-size:14px">🌐 Conheça a Despache Fácil</a>\n    </div>\n\n    <div style="text-align:center;border-top:1px solid #e5e7eb;padding-top:18px;margin-top:8px">\n      <p style="margin:0 0 4px;color:#111827;font-size:15px;font-weight:bold">Cliente Teste</p>\n      <p style="margin:0;color:#6b7280;font-size:12px">Logística operada por Despache Fácil</p>\n    </div></td></tr>\n  <tr><td style="background:#f9fafb;padding:18px 40px;text-align:center;border-top:1px solid #e5e7eb">\n    <p style="margin:0;color:#9ca3af;font-size:12px">&copy; 2026 Despache Fácil. Em caso de dúvida, responda este e-mail.</p>\n  </td></tr>\n</table></td></tr></table></body></html>	💳 Pagamento confirmado com sucesso!\nOlá, Maria Silva!\nSeu pagamento foi confirmado pela Monetizze e seu pedido já foi enviado pela Despache Fácil em nome de Cliente Teste.\n📦 PRODUTO: KIT RESTART INTESTINAL\nQuantidade: 1\nValor total: R$ 147,00\nTransportadora: Correios - Sedex\nCódigo de rastreio: AD391354255BR\n⏱️ Previsão de entrega: 1 dias úteis\nO código de rastreio pode levar até 24h para começar a mostrar atualizações.\nSeu pedido foi processado, embalado e enviado com segurança pela Despache Fácil, responsável pela logística da Cliente Teste.\nSe você também deseja enviar seus produtos com automação e praticidade, acesse:\n🌐 https://despachefacil.com\nCliente Teste\nLogística operada por Despache Fácil	sent	resend	9dc05b76-3a43-43f3-872a-5837b8574ebf	\N	monetizze:shipped	28	\N	2	2026-05-05 17:33:58.040771
4	comprador.teste@example.com	Cliente Teste via Despache Fácil <envios@despachefacil.com>	💳 Pagamento confirmado — Kit Mais Natture - 1 unidade já foi enviado!	<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>\n<body style="margin:0;padding:0;background:#f4f4f5;font-family:Arial,sans-serif">\n<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f5;padding:40px 0"><tr><td align="center">\n<table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08)">\n  <tr><td style="background:#0B3C5D;padding:28px;text-align:center">\n    <h1 style="margin:0;color:#ffffff;font-size:24px;font-weight:bold">Despache Fácil</h1>\n    <p style="margin:6px 0 0;color:rgba(255,255,255,0.85);font-size:14px">Pedido enviado</p>\n  </td></tr>\n  <tr><td style="padding:36px 40px">\n    <p style="margin:0 0 18px;color:#111827;font-size:20px;font-weight:bold;text-align:center">\n      💳 Pagamento confirmado com sucesso!\n    </p>\n    <p style="margin:0 0 22px;color:#374151;font-size:15px;line-height:1.6">\n      Olá, Comprador Teste! Seu pagamento foi confirmado pela <strong>Monetizze</strong> e seu pedido já foi <strong>enviado e despachado</strong> pela <strong>Despache Fácil</strong>, em nome de <strong>Cliente Teste</strong>.\n    </p>\n\n    <div style="background:#f0fdf4;border:2px solid #00C853;border-radius:10px;padding:18px 20px;margin:0 0 22px;text-align:center">\n      <div style="color:#065f46;font-size:13px;font-weight:600;letter-spacing:0.5px;margin-bottom:6px">📦 PRODUTO</div>\n      <div style="color:#064e3b;font-size:20px;font-weight:bold;line-height:1.3;text-transform:uppercase">KIT MAIS NATTURE - 1 UNIDADE</div>\n    </div>\n\n    <table width="100%" cellpadding="0" cellspacing="0" style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:8px;margin:0 0 22px">\n      <tr><td style="padding:12px 18px;color:#6b7280;font-size:14px">Quantidade de itens</td><td style="padding:12px 18px;text-align:right;color:#111827;font-size:14px;font-weight:600">1</td></tr>\n      <tr><td style="padding:12px 18px;color:#6b7280;font-size:14px;border-top:1px solid #e5e7eb">Valor total do pedido</td><td style="padding:12px 18px;text-align:right;color:#111827;font-size:14px;font-weight:600;border-top:1px solid #e5e7eb">R$ 197,00</td></tr>\n      <tr><td style="padding:12px 18px;color:#6b7280;font-size:14px;border-top:1px solid #e5e7eb">Transportadora</td><td style="padding:12px 18px;text-align:right;color:#111827;font-size:14px;font-weight:600;border-top:1px solid #e5e7eb">Correios</td></tr>\n      <tr><td style="padding:14px 18px;color:#00C853;font-size:14px;font-weight:bold;border-top:1px solid #e5e7eb">Código de rastreio</td><td style="padding:14px 18px;text-align:right;color:#0B3C5D;font-size:18px;font-weight:bold;border-top:1px solid #e5e7eb;font-family:monospace">AD390403508BR</td></tr>\n    </table>\n\n    <p style="margin:0 0 16px;color:#111827;font-size:15px;line-height:1.6">\n      ⏱️ <strong>Previsão de entrega:</strong> 1 dias úteis\n    </p>\n\n    <div style="text-align:center;margin:0 0 22px">\n      <a href="https://rastreamento.correios.com.br" style="display:inline-block;background:#0B3C5D;color:#ffffff;text-decoration:none;padding:11px 24px;border-radius:6px;font-weight:bold;font-size:14px">📍 Rastrear no site dos Correios</a>\n      <p style="margin:8px 0 0;color:#6b7280;font-size:12px">Use o código acima em rastreamento.correios.com.br</p>\n    </div>\n\n    <div style="background:#fffbeb;border-left:4px solid #f59e0b;border-radius:4px;padding:12px 16px;margin:0 0 22px">\n      <p style="margin:0;color:#92400e;font-size:13px;line-height:1.5">\n        ℹ️ O código de rastreio pode levar até <strong>24h</strong> para começar a mostrar atualizações.\n      </p>\n    </div>\n\n    <p style="margin:0 0 22px;color:#374151;font-size:14px;line-height:1.6">\n      Seu pedido foi <strong>processado, embalado e enviado com segurança</strong> pela Despache Fácil, responsável pela logística da Cliente Teste.\n    </p>\n\n    <div style="background:#0B3C5D;border-radius:10px;padding:20px;text-align:center;margin:0 0 22px">\n      <p style="margin:0 0 12px;color:#ffffff;font-size:14px;line-height:1.5">\n        Quer enviar seus produtos com <strong>automação e praticidade</strong>?\n      </p>\n      <a href="https://despachefacil.com" style="display:inline-block;background:#00C853;color:#ffffff;text-decoration:none;padding:11px 24px;border-radius:6px;font-weight:bold;font-size:14px">🌐 Conheça a Despache Fácil</a>\n    </div>\n\n    <div style="text-align:center;border-top:1px solid #e5e7eb;padding-top:18px;margin-top:8px">\n      <p style="margin:0 0 4px;color:#111827;font-size:15px;font-weight:bold">Cliente Teste</p>\n      <p style="margin:0;color:#6b7280;font-size:12px">Logística operada por Despache Fácil</p>\n    </div></td></tr>\n  <tr><td style="background:#f9fafb;padding:18px 40px;text-align:center;border-top:1px solid #e5e7eb">\n    <p style="margin:0;color:#9ca3af;font-size:12px">&copy; 2026 Despache Fácil. Em caso de dúvida, responda este e-mail.</p>\n  </td></tr>\n</table></td></tr></table></body></html>	💳 Pagamento confirmado com sucesso!\nOlá, Comprador Teste!\nSeu pagamento foi confirmado pela Monetizze e seu pedido já foi enviado pela Despache Fácil em nome de Cliente Teste.\n📦 PRODUTO: KIT MAIS NATTURE - 1 UNIDADE\nQuantidade: 1\nValor total: R$ 197,00\nTransportadora: Correios - Sedex\nCódigo de rastreio: AD390403508BR\n⏱️ Previsão de entrega: 1 dias úteis\n📍 Rastreie no site dos Correios: https://rastreamento.correios.com.br (use o código AD390403508BR)\nO código de rastreio pode levar até 24h para começar a mostrar atualizações.\nSeu pedido foi processado, embalado e enviado com segurança pela Despache Fácil, responsável pela logística da Cliente Teste.\nSe você também deseja enviar seus produtos com automação e praticidade, acesse:\n🌐 https://despachefacil.com\nCliente Teste\nLogística operada por Despache Fácil	sent	resend	5583c259-012c-4523-afda-53456289b4a8	\N	monetizze:shipped	28	\N	1	2026-06-18 17:51:55.463533
\.


--
-- Data for Name: monetizze_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.monetizze_orders (id, sale_code, product_code, product_name, owner_user_id, shipment_id, status, kit_count, weight, height, width, length, recipient_name, recipient_email, recipient_phone, recipient_cpf_cnpj, recipient_address, recipient_zip, carrier, carrier_code, service_code, tracking_code, tracking_eligible_at, tracking_sent_at, final_price, sale_value, retry_count, last_error, raw_payload, email_approved_sent_at, email_preparing_sent_at, email_shipped_sent_at, email_delivered_sent_at, created_at, updated_at, email_out_for_delivery_sent_at, email_materials_sent_at, materials_processed_at, materials_emailed_codes, tracking_notified_at) FROM stdin;
1	MZ-SIMULA-001	P-MAIS-NATTURE	Kit Mais Natture - 1 unidade	28	19	cancelado	1	0.20	16.00	14.00	18.00	Comprador Teste	comprador.teste@example.com	11999998888	12345678909	Av Paulista 1000, ap 100, ap 100, São Paulo - SP	01310100	Correios - Sedex	COR	03220	AD390403508BR	2026-04-29 22:53:56.291	\N	14.22	197.00	1	Cancelado pelo admin	{"venda": {"valor": 197, "codigo": "MZ-SIMULA-001", "status": "Finalizada"}, "produto": {"nome": "Kit Mais Natture - 1 unidade", "codigo": "P-MAIS-NATTURE"}, "comprador": {"cep": "01310100", "nome": "Comprador Teste", "email": "comprador.teste@example.com", "cidade": "São Paulo", "estado": "SP", "endereco": "Av Paulista 1000, ap 100", "telefone": "11999998888", "documento": "12345678909", "complemento": "ap 100"}}	2026-04-28 22:53:08.124	2026-04-28 22:53:56.454	2026-06-18 17:51:55.534	\N	2026-04-28 22:53:07.860917	2026-06-18 17:51:55.54	\N	\N	\N	{}	2026-06-18 17:51:55.54
2	MZ-REAL-99999	331054	kit Restart Intestinal	28	20	enviado	1	0.20	16.00	14.00	18.00	Maria Silva	maria.silva@example.com	11988887777	12345678909	Av Paulista 100, Sao Paulo - SP	01310100	Correios - Sedex	COR	03220	AD391354255BR	2026-04-30 12:24:04.824	\N	14.22	147.00	0	Push rastreio falhou: Você não pode alterar dados desta transação, ela não pertence a você. Entre em contato com o produtor para que ele habilite.	{"venda": {"valor": "147.00", "codigo": "MZ-REAL-99999", "status": "Finalizada", "quantidade": "1"}, "produto": {"nome": "kit Restart Intestinal", "chave": "7d8e4d8a9828dbdcbde7456640db8959", "codigo": "331054", "categoria": "Saude"}, "comprador": {"cep": "01310100", "nome": "Maria Silva", "email": "maria.silva@example.com", "cidade": "Sao Paulo", "estado": "SP", "endereco": "Av Paulista 100", "telefone": "11988887777", "documento": "12345678909"}, "tipoEvento": {"codigo": "2", "descricao": "Finalizada / Aprovada"}, "chave_unica": "2bb0b1ee68791e665b58b9fc21aa433d", "tipoPostback": {"codigo": "2", "descricao": "Produtor"}, "venda[valor]": "147.00", "produto[nome]": "kit Restart Intestinal", "venda[codigo]": "MZ-REAL-99999", "venda[status]": "Finalizada", "comprador[cep]": "01310100", "produto[chave]": "7d8e4d8a9828dbdcbde7456640db8959", "comprador[nome]": "Maria Silva", "produto[codigo]": "331054", "comprador[email]": "maria.silva@example.com", "comprador[cidade]": "Sao Paulo", "comprador[estado]": "SP", "venda[quantidade]": "1", "produto[categoria]": "Saude", "tipoEvento[codigo]": "2", "comprador[endereco]": "Av Paulista 100", "comprador[telefone]": "11988887777", "comprador[documento]": "12345678909", "tipoPostback[codigo]": "2", "tipoEvento[descricao]": "Finalizada / Aprovada", "tipoPostback[descricao]": "Produtor"}	2026-04-29 12:24:02.207	2026-04-29 12:24:04.923	2026-05-05 17:33:58.223	\N	2026-04-29 12:24:01.994642	2026-08-28 14:02:52.22	\N	\N	\N	{}	2026-06-18 17:51:55.547
\.


--
-- Data for Name: payment_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_orders (id, user_id, asaas_payment_id, asaas_customer_id, amount, method, status, pix_qr_code, pix_copy_paste, invoice_url, created_at, paid_at, asaas_net_value, asaas_fee, frenet_share, margin_share, frenet_transferred_at) FROM stdin;
1	28	pay_lpfk0av3g7rd3xp1	cus_000171616449	5.00	PIX	aguardando_pagamento	iVBORw0KGgoAAAANSUhEUgAAAcIAAAHCAQAAAABUY/ToAAADFUlEQVR4Xu2UwY7cMAxDc8v//1E/K7d0+Sg50wUKF3upAlDZcSyKj3uwZ477h/Xr+K78a4XcVchdhdxVyF2F3NV/I6+DOu/rpNF6Xm7ZHieqduUMOZlcjgOPlrPyTmX0QHHtDzmYLFWvW+feT6GS7xo0H3I8qafpWmth1TDki8ibs74ZAEtlVSs15DtIrGbbhtX+Jh5nyNEkh64T3j7lDPnXZwD5lKd9+mTi5mL4GnSFHEtqVg4weHp3EhatJ+R0Uohf8DUX4TDzzYYcTjLTWRegEbhyLDjT/0XzkGNJm6x+h+tyFO+kkMPJLxWHAwBsr7hOcJzfIceS+EQsu0SfuLRSEBVBF3IweSLJJtUQ9wEZh10rMeRcstnSZe9evF79JjvkbPKiqxW8UTqSRBDcGSHHkt18ej7UtchBpLYhB5MIQnoEZeXsvTMZhhxOnv5e9w5IBvUfiumQ00ltLRvpVcvnxuaQs8nLhyv7yum1EgqoCE1CziV1B1zIOEt1K7sSrICGHEtik4W5Xu6gCcFtNeQLSDkA2Hjv8y/40a2GHExqx0ejOnY1VnwXdAFakRByLqm6nl/qCkI5fT+q659uoSHHkmVlauvNV5uWBtP1YCFHkzikl6fOXTegCsGmy3LIsaTMnHh9CBAvT92LldK7kIPJ22e8jnkF0BnkvqAghhxMSmdUtjYpcO2NhBxP+gbIQoiuhZLIXAp8WUOOJm84f+SSgyySHAFCiMGQc0mpGvRSbnZKObx5xpqGnEtqrIlGXzv3ctn7Zw5wyMGkFU0Old1scHvq3kvI0aRGBGBcXjw2qyewpyEHk6BSP2Bn1QhoXQVPQw4m1Xv11prLE7/9CTmbbBBdh64Tr7NH8dBZ9cUOOZfswgKoYQEEdqIV0JBjSR+xJN+JJmSvOP5KQQo5mLS7XTX2uSuKPMWWHHI6qZmRgn036nro0dVoQf8n5BtIbQvvM+f8XfZJDPkSsg36w2KNbkFUyMFkARr5aXsL9ZVefyEnk/0bzLTd6ERIYExbr5BjyR9VyF2F3FXIXYXcVchdvYz8DfrWZ9OGKFmQAAAAAElFTkSuQmCC	00020101021226800014br.gov.bcb.pix2558pix.asaas.com/qr/cobv/11f0d3d4-1a8e-4ef9-9b71-8c32620eca985204000053039865802BR5919DESPACHE FACIL LTDA6009Fortaleza61086032033062070503***63041C31	https://www.asaas.com/i/lpfk0av3g7rd3xp1	2026-04-17 11:40:54.761938	\N	\N	\N	\N	\N	\N
2	28	pay_ms94ke0ks8cc2quf	cus_000171616449	5.00	PIX	aguardando_pagamento	iVBORw0KGgoAAAANSUhEUgAAAcIAAAHCAQAAAABUY/ToAAADGUlEQVR4Xu2UQXLcQAwDddP/f5Rn6aYsGuRISSUlly+mqsBdS0MQDR+G9nZ+s35tfytfrZBPFfKpQj5VyKcK+VQ/Rh4btZ/HznE/9o+4l0Wi9DXWMeRkEhMOxxRaxz6UXv6Qg8lLRS9woRt3r4W4nCHHk2I2mb0OetaDJ5Eh30Ny0viUqIxNk0KlhnwHibVcNcNqfxOXM+RoUgT+x085Q/73M4Bc5YuXhReZuFkMr0FXyLGkZjj2tlcvRRIrUHTlhpxLNrprhBvNhL5qSS025GgSt501bqsid86Vjhc05FzSQ4x1z7pvPuzG4p0UcjgpQJoO7Si0jz20O+RkUq0a04zNK+ausSzVhRxL0p/6kVETeu4e1b2ZSgw5mrRxQfAY6tVvTUIOJ9Vv3oZiG5XHrQjxKyPkZFJnNDE6V1tuP/pXcA45ljy0AsYbtV1H4jStbbA55GRy679r4QXZQO9MTNAhp5NoeP54czRaCyG33yHHkr7ldviiWYvajINNYGSf5iHHkoB19/4j1gylWmLt+cf/hJCzyNPXrKcHoCig11Y4NeRs8tAKcNc12bwTKIYt9UaEnE7WvduqgV/ObEsrzEOOJT/tKg+X+LF13s2geci5pMy0F7bbyiIwQmks5GQSt2C8jWkJyqWpYy455FhSVn0aY6QkHRTbWnv1DjmXbF9tglqH6HsPtoIYcjBJK3A9bCKrz0ZCvoCU0H/KvRWcO7b4moUcTZZUtA8a41Dvl5UCQ84lpQsRoyun7TAPYQS3GHI0qbMmSqirlstexVw5wCFHkxqoZCu3O7nx36ZOCjmXvN3wcXnxVBTzW1LI8SSOfjK8hZJQOWghJ5Pq20HKLs3lVL/9E3I2aVBS+ZRQd0/cPYs25GSyyxaGiqkQhcFzIjbkaNJXDNBDf1cAr1aQQg4mdeoZ7BXyCdRT6C025GxSM9mdQl+FDFUarpCvIJdPQ134wXbgXD7CQ76BBKiIsthGtyAq5GCSqcgK2ZaDIImKltPfkJPJ/h+8+bLLKd0JnUdbr5BjyW9VyKcK+VQhnyrkU4V8qpeRvwGgaRgjSbG9ZAAAAABJRU5ErkJggg==	00020101021226800014br.gov.bcb.pix2558pix.asaas.com/qr/cobv/2140285a-15ad-403a-a556-f4ff870c57c95204000053039865802BR5919DESPACHE FACIL LTDA6009Fortaleza61086032033062070503***6304134B	https://www.asaas.com/i/ms94ke0ks8cc2quf	2026-04-17 11:42:07.53248	\N	\N	\N	\N	\N	\N
3	28	pay_9id6gvmvkt35l812	cus_000171616449	5.00	PIX	aguardando_pagamento	iVBORw0KGgoAAAANSUhEUgAAAcIAAAHCAQAAAABUY/ToAAADGElEQVR4Xu2UQY7bUAxDs8v9b9RjeZeGj5QdtChcdFMFoKa2JYqPs/h/+nj9Y/14/Kr8bZW8q5J3VfKuSt5Vybv6b+TxoJ7v5nn48zrSvZWnHdbiLLmZVGdvANsxWnW+G/tLLiatxn7tScHPysHhS64nafj3CZwVQ8lvIXm/H0l08//ymVHyO8iob/0p6AX1JEA93nnyLrmXlI/97U+cJf/4s4Ccep+7jv7jvKXYzhc9VXItyV7v6Yk4i6zxJLzkYhJIevznYCsO5Yn1quRy8sHZSzmua2GUBCorAkruJcVE4vOaa3Cl5YaoT0zJtSSoJI56zj8NSBKwopdcTOZwcwVkMzPmKKKQ8ZdcTLLkwce/iJOJi8FiybXkrHTeR1hJfJBGS6aQkmtJn+1h6eTHJd33RGK2JVeTDAZlDR7PIOr5BXQl15JayijFMgKJk4BObG5MybVkBAD5KTv8suKwuRIl15IC4lPP+duFZNUXQr/Gl6XkYtKTFupFEpWORwkm7Su5ljzmLxc/tpHkkeHS5jeUXEuylIL84MwVQiaA21lTJfeSceoTgof5qjh+/z+h5C7y9H445lr44PGeSsnt5HXmp/2M0cRw3YuSu8kHh6sAnfnERArKg5MbUXIveXn5QCSHgYXcw5fcTQKPRucEjyEZHF9yN6lT12xIOjOyJ0JitFZyLTk2sTlqTYxPr4mFSXTJxSTDBcoJ71UAHmbQknvJLORkh4fp5fXsklJyO/l++TqE5rgtuXIlEEruJl92aqE/aVCNrMJO+rkouZY8GA5uwpDqneU8dHMsS64mtfBmksxlhMwkuORm8qUWzGaTDnMLO1fB8SUXkx7UyOkvIE735x5Hyb2kQd6H7wFuSr5Mp0RIybXk1EFAQCEwmgJHgS25ljwP3bvzEeTr8fHjy1FyM6kub33kyLUw59AohJVcTbLQPFaMvDWTZVkYzpLrSSlxTgBpkiFClfwOMh5ZhjSQK0EAYSV3k2rfTrx4xPN2nuPQS+4nddRGPlxOwX7eCTZOLbmW/KcqeVcl76rkXZW8q5J39WXkTxsnmYVP87teAAAAAElFTkSuQmCC	00020101021226800014br.gov.bcb.pix2558pix.asaas.com/qr/cobv/40d8c03c-92a8-4a96-8746-1b634e07db665204000053039865802BR5919DESPACHE FACIL LTDA6009Fortaleza61086032033062070503***6304FF14	https://www.asaas.com/i/9id6gvmvkt35l812	2026-04-17 11:45:22.607573	\N	\N	\N	\N	\N	\N
4	28	pay_5qlh4bzh196npoib	cus_000171616449	5.00	PIX	aguardando_pagamento	iVBORw0KGgoAAAANSUhEUgAAAcIAAAHCAQAAAABUY/ToAAADH0lEQVR4Xu2US47bQAxEtdP9b5Rjaee4XpEtZYCgB7MZGijalvipV1mQk+P1w/hzfO18N0LuIuQuQu4i5C5C7uLXyOsgTjWu813qVz0l78f57r9nD2XIuWQzvDRAUx6CVPG7lSEHk9VtudR8OAO7yLPykJ9BqnOJPddTbAXWIT+J7PFLzZLztOOtDDmbRNpzjXn1RG0RT2XIwSRL5xZ2n1KG/O9nAHnHZV6zPoq+AeSPCDmWtAhB/T0XYUb/d9vs6RByLMmwRVK8z0EXsSyP9VevzGzIuaS1lpWelprlWAZ6yTPkYFI7hkdbabX/2T6chyHnkuowfP5KZjfGyzjkcLIPwR54VVz+e3Zun1KHdAwkveC1Zi1dNVAfhWph5kPOJv1olYFSYwXkQnXI0aQw9DaBktYal0w9DjmcJEMowBrXEvE18mKIPORc0nBt3C4Sk4P4EFaKJuRcco18DlZoLNJnIGN05RZyLtnaQxoYrNwos+WAV8jJJDD6U32lfRVk/EzLTOOQk8mrF6+8xNVUBWOODuOQc8kGvGZJfBZKpXoYLuOQY0k23NuW9lL57PApjT1DDibdMcBMIzrWCbuvgGnI4aSu4dC8Y92HHq5KARpyLnkjtmgeS0mPvghazEIOJpkevXTJFC1CQu0m7ZCTyeLMe8QZuFtF+fgdci5J6qHViLkGnCgYVSvkZBIIA44BIWyJKy/H+pdCDiYFoODphbfOjusi5BZyNllEv5CgwENP/6qHY8i5pBovLVnC476K0ya0LIB73lDIgaTR5SBsGfEsHhGOIYeTVtbGJbWKlwxLYTTkeJJKY32r4BJ8B2VBajzkXLK61orzcI1qoltZRxJyMKnaMn1r6u7qgdol5Gjylhx9DkpuqSRNmws5mOwo0BNp7WZaaXUQhBxLesXeMfSqDbhcHd1HyMmkMtYtsuSuzj6EPoF6hRxNsv/H9OvyZfC8j5AfQXIHfJW9NEJ7qKiui5CfQFruvVfF1puqigg5mGQq/p4KRe6+99/KkKNJJt5+62memtlQvMuQ08kfRchdhNxFyF2E3EXIXXwY+Rderb97MBCowAAAAABJRU5ErkJggg==	00020101021226800014br.gov.bcb.pix2558pix.asaas.com/qr/cobv/0a8f825e-5818-4f53-8cf5-57b1244ffba35204000053039865802BR5919DESPACHE FACIL LTDA6009Fortaleza61086032033062070503***6304BEF9	https://www.asaas.com/i/5qlh4bzh196npoib	2026-04-17 11:47:55.397882	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: platform_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.platform_settings (id, key, value) FROM stdin;
1	freight_margin_percent	30
3	monetizze_owner_user_id	28
4	monetizze_tracking_delay_hours	24
5	monetizze_jadlog_threshold_pct	0.15
6	monetizze_enabled	true
7	monetizze_origin_zip	38307428
2	backup_last_cron_week	2026-W24
9	monetizze_customer_notify_start_at	2026-06-18T19:01:33.815Z
10	whatsapp_safe_pacing_started_at	2026-08-24T21:55:00.291Z
8	backup_last_cron_day	2026-08-31
\.


--
-- Data for Name: processed_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.processed_payments (id, stripe_session_id, user_id, amount, processed_at) FROM stdin;
\.


--
-- Data for Name: product_materials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_materials (id, product_code, display_name, store_name, video_url, manual_url, training_url, vip_group_url, support_url, warranty, repurchase_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: quote_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quote_history (id, user_id, origin_zip, dest_zip, weight, height, width, length, carrier, original_price, final_price, delivery_time, created_at) FROM stdin;
7	25	01310100	20040020	1.00	10.00	10.00	15.00	Jadlog - Jadlog Package	16.74	21.76	4	2026-03-13 17:16:57.025964
8	25	01310100	20040020	1.00	10.00	10.00	15.00	Correios - PAC	21.00	27.30	5	2026-03-13 17:16:57.032772
9	25	01310100	20040020	1.00	10.00	10.00	15.00	Correios - Sedex	29.99	38.99	1	2026-03-13 17:16:57.035975
10	26	01310100	20040020	1.00	10.00	10.00	15.00	Jadlog - Jadlog Package	16.74	21.76	4	2026-03-13 17:18:54.654736
11	26	01310100	20040020	1.00	10.00	10.00	15.00	Correios - PAC	21.00	27.30	5	2026-03-13 17:18:54.660209
12	26	01310100	20040020	1.00	10.00	10.00	15.00	Correios - Sedex	29.99	38.99	1	2026-03-13 17:18:54.673081
13	25	01310100	20040020	1.00	10.00	10.00	15.00	Jadlog - Jadlog Package	16.74	21.76	4	2026-03-13 17:20:58.162038
14	25	01310100	20040020	1.00	10.00	10.00	15.00	Correios - PAC	21.00	27.30	5	2026-03-13 17:20:58.202198
15	25	01310100	20040020	1.00	10.00	10.00	15.00	Correios - Sedex	29.99	38.99	1	2026-03-13 17:20:58.206998
16	27	01310100	20040020	1.00	10.00	10.00	15.00	Jadlog - Jadlog Package	16.74	21.76	4	2026-03-13 19:55:04.672033
17	27	01310100	20040020	1.00	10.00	10.00	15.00	Correios - PAC	21.00	27.30	5	2026-03-13 19:55:04.748659
18	27	01310100	20040020	1.00	10.00	10.00	15.00	Correios - Sedex	29.99	38.99	1	2026-03-13 19:55:04.751598
19	28	38307428	01310100	0.50	10.00	15.00	20.00	Jadlog - Jadlog Package	11.77	15.30	5	2026-03-14 16:08:27.421388
20	28	38307428	01310100	0.50	10.00	15.00	20.00	Correios - PAC	23.46	30.50	6	2026-03-14 16:08:27.662599
21	28	38307428	01310100	0.50	10.00	15.00	20.00	Correios - Sedex	45.00	58.50	2	2026-03-14 16:08:27.742987
22	28	01310100	22041011	1.00	10.00	15.00	20.00	Jadlog - Jadlog Package	16.74	21.76	4	2026-03-21 19:10:07.55218
23	28	01310100	22041011	1.00	10.00	15.00	20.00	Correios - PAC	21.00	27.30	5	2026-03-21 19:10:07.713016
24	28	01310100	22041011	1.00	10.00	15.00	20.00	Correios - Sedex	29.99	38.99	1	2026-03-21 19:10:07.724452
25	28	01310100	22041011	1.00	10.00	15.00	20.00	Jadlog - Jadlog Package	16.74	21.76	4	2026-03-21 19:12:09.365808
26	28	01310100	22041011	1.00	10.00	15.00	20.00	Correios - PAC	21.00	27.30	5	2026-03-21 19:12:09.39695
27	28	01310100	22041011	1.00	10.00	15.00	20.00	Correios - Sedex	29.99	38.99	1	2026-03-21 19:12:09.408364
28	28	01310100	22041011	1.00	10.00	15.00	20.00	Jadlog - Jadlog Package	16.74	21.76	4	2026-03-23 12:59:01.554083
29	28	01310100	22041011	1.00	10.00	15.00	20.00	Correios - PAC	21.00	27.30	5	2026-03-23 12:59:01.592923
30	28	01310100	22041011	1.00	10.00	15.00	20.00	Correios - Sedex	29.99	38.99	1	2026-03-23 12:59:01.604851
31	28	01310100	22041011	1.00	10.00	15.00	20.00	Jadlog - Jadlog Package	16.74	21.76	4	2026-03-23 13:15:48.832603
32	28	01310100	22041011	1.00	10.00	15.00	20.00	Correios - PAC	21.00	27.30	5	2026-03-23 13:15:48.866216
33	28	01310100	22041011	1.00	10.00	15.00	20.00	Correios - Sedex	29.99	38.99	1	2026-03-23 13:15:48.877249
34	28	01310100	22041011	1.00	10.00	15.00	20.00	Jadlog - Jadlog Package	16.74	21.76	4	2026-03-23 13:18:13.321589
35	28	01310100	22041011	1.00	10.00	15.00	20.00	Correios - PAC	21.00	27.30	5	2026-03-23 13:18:13.354201
36	28	01310100	22041011	1.00	10.00	15.00	20.00	Correios - Sedex	29.99	38.99	1	2026-03-23 13:18:13.365833
37	28	01310100	20040020	0.50	10.00	10.00	15.00	Jadlog - Jadlog Package	15.68	20.38	4	2026-03-23 14:12:05.030505
38	28	01310100	20040020	0.50	10.00	10.00	15.00	Correios - PAC	19.60	25.48	5	2026-03-23 14:12:05.227424
39	28	01310100	20040020	0.50	10.00	10.00	15.00	Correios - Sedex	28.83	37.48	1	2026-03-23 14:12:05.231593
40	28	01310100	20040020	1.00	10.00	10.00	10.00	Jadlog - Jadlog Package	16.74	21.76	4	2026-03-24 15:21:32.721116
41	28	01310100	20040020	1.00	10.00	10.00	10.00	Correios - PAC	21.00	27.30	5	2026-03-24 15:21:32.995364
42	28	01310100	20040020	1.00	10.00	10.00	10.00	Correios - Sedex	29.99	38.99	1	2026-03-24 15:21:33.038511
43	28	01310100	80060000	0.50	10.00	15.00	20.00	Jadlog - Jadlog Package	15.63	20.32	4	2026-03-27 13:52:37.228893
44	28	01310100	80060000	0.50	10.00	15.00	20.00	Correios - PAC	19.60	25.48	5	2026-03-27 13:52:37.594417
45	28	01310100	80060000	0.50	10.00	15.00	20.00	Correios - Sedex	28.83	37.48	1	2026-03-27 13:52:37.604873
46	28	01310100	04094050	1.00	15.00	20.00	25.00	Correios - Sedex	12.94	16.82	1	2026-04-17 12:00:24.307318
47	28	01310100	04094050	1.00	15.00	20.00	25.00	Jadlog - Jadlog Package	16.79	21.83	4	2026-04-17 12:00:24.314354
48	28	01310100	04094050	1.00	15.00	20.00	25.00	Correios - PAC	19.39	25.21	5	2026-04-17 12:00:24.318128
49	33	01310100	04543000	1.00	10.00	10.00	15.00	Correios - Sedex	12.94	16.82	1	2026-04-22 19:57:29.36174
50	33	01310100	04543000	1.00	10.00	10.00	15.00	Jadlog - Jadlog Package	16.79	21.83	4	2026-04-22 19:57:29.370076
51	33	01310100	04543000	1.00	10.00	10.00	15.00	Correios - PAC	19.39	25.21	5	2026-04-22 19:57:29.375736
52	33	01310100	04543000	1.00	10.00	10.00	15.00	Correios - Sedex	17.72	23.04	1	2026-04-22 19:57:29.700589
53	33	01310100	04543000	1.00	10.00	10.00	15.00	Jadlog - Jadlog Package	17.83	23.18	4	2026-04-22 19:57:29.705447
54	33	01310100	04543000	1.00	10.00	10.00	15.00	Correios - PAC	24.17	31.42	5	2026-04-22 19:57:29.708722
\.


--
-- Data for Name: shipments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shipments (id, user_id, recipient_name, address, carrier, original_price, final_price, delivery_time, created_at, platform_profit, status, tracking_code, updated_at, recipient_phone, recipient_cpf_cnpj, origin_zip, dest_zip, content_declaration, invoice_number, weight, height, width, length, sender_full_address, service_code, carrier_code, declared_value, frenet_shipment_id, frenet_label_url, frenet_tracking_url, sender_cpf_cnpj, frenet_error_message, frenet_declaration_url, volumes, hidden_at) FROM stdin;
11	28	Ana Costa	Rua da Bahia 300, Centro, Belo Horizonte MG 30160-011	Jadlog - Jadlog Package	15.63	20.32	4	2026-03-28 14:19:45.694776	4.69	postado	568260039	2026-07-24 14:31:17.045	31966665555	33322255561	01310100	30160011	Produtos diversos item 3		0.50	10.00	15.00	20.00	Av Paulista 1000, Bela Vista, São Paulo SP 01310-100	F_3	JAD	50.00	22826391	https://painel.frenet.com.br/label?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIyODI2Mzkx&format=A4	https://rastreio.frenet.com.br/JAD/568260039	12345678901	\N	https://painel.frenet.com.br/label/Declaration?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIyODI2Mzkx&format=A4	1	\N
4	28	João da Silva	Rua das Flores, 123 - Centro - São Paulo/SP - 01001-000	CORREIOS	25.00	32.50	5	2026-03-20 15:09:19.436795	7.50	aguardando_postagem	BR123456789BR	2026-03-20 15:09:19.436795	11999990001	529.982.247-25	01001000	20040020	Livros e papelaria	NF-001	1.00	20.00	30.00	40.00	Av. Paulista, 1000 - Bela Vista - São Paulo/SP - 01310-100	\N	\N	\N	\N	\N	\N		\N	\N	1	\N
5	28	Maria Souza	Rua XV de Novembro, 500 - Centro - Curitiba/PR - 80020-310	JADLOG	35.00	45.50	3	2026-03-20 15:09:19.436795	10.50	aguardando_postagem	JD987654321BR	2026-03-20 15:09:19.436795	11988880002	111.444.777-35	01001000	80020310	Eletrônicos	NF-002	2.00	30.00	40.00	50.00	Av. Paulista, 1000 - Bela Vista - São Paulo/SP - 01310-100	\N	\N	\N	\N	\N	\N		\N	\N	1	\N
6	28	Carlos Ferreira	Rua da Consolação, 200 - Consolação - São Paulo/SP - 01302-001	CORREIOS	18.00	23.40	7	2026-03-20 15:09:19.436795	5.40	aguardando_postagem	BR000000001BR	2026-03-20 15:09:19.436795	21977770003	222.333.444-05	01001000	01302001	Documentos	NF-003	0.50	10.00	20.00	30.00	Av. Paulista, 1000 - Bela Vista - São Paulo/SP - 01310-100	\N	\N	\N	\N	\N	\N		\N	\N	1	\N
7	28	Ana Lima	Av. Afonso Pena, 100 - Centro - Belo Horizonte/MG - 30130-001	TOTAL	42.00	54.60	6	2026-03-20 15:09:19.436795	12.60	aguardando_postagem	TO111111111BR	2026-03-20 15:09:19.436795	31966660004	333.444.555-87	01001000	30130001	Roupas e acessórios	NF-004	3.00	25.00	35.00	45.00	Av. Paulista, 1000 - Bela Vista - São Paulo/SP - 01310-100	\N	\N	\N	\N	\N	\N		\N	\N	1	\N
9	28	João Teste	Av Paulista, 1000, Bela Vista, São Paulo/SP	Jadlog - Jadlog Package	11.77	15.30	5	2026-03-23 15:24:21.093637	3.53	aguardando_frenet	\N	2026-03-23 15:24:21.219	11999990000		38307428	01310100	Suplemento vitamínico		0.50	10.00	15.00	20.00	Rua Carlos Martins, 905, Centro, Ituiutaba/MG	F_3	JAD	50.00	\N	\N	\N	12345678909	FRENET_CPF_REQUIRED: CPF/CNPJ do destinatário é obrigatório ou inválido para esta transportadora. Corrija e use o botão Retentar.	\N	1	\N
17	28	Carlos Ferreira	Rua das Flores 100, Centro, Curitiba PR 80020-010	Jadlog - Jadlog Package	15.63	20.32	4	2026-03-28 14:23:22.083359	4.69	postado	568265069	2026-07-24 14:31:18.276	41988881111	44455566677	01310100	80020010	Materiais lote 5		0.50	10.00	15.00	20.00	Av Paulista 1000, Bela Vista, São Paulo SP 01310-100	F_3	JAD	50.00	22826457	https://painel.frenet.com.br/label?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIyODI2NDU3&format=A4	https://rastreio.frenet.com.br/JAD/568265069	12345678901	\N	https://painel.frenet.com.br/label/Declaration?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIyODI2NDU3&format=A4	1	\N
8	28	Pedro Santos	Rua dos Andradas, 300 - Centro Histórico - Porto Alegre/RS - 90020-000	CORREIOS	55.00	71.50	8	2026-03-20 15:09:19.436795	16.50	aguardando_postagem	BR222222222BR	2026-03-20 15:09:19.436795	41955550005	444.555.666-52	01001000	90020000	Utensílios domésticos	NF-005	5.00	40.00	50.00	60.00	Av. Paulista, 1000 - Bela Vista - São Paulo/SP - 01310-100	\N	\N	\N	\N	\N	\N		\N	\N	1	\N
10	28	João Teste Silva	Rua XV de Novembro 100, Centro, Curitiba PR 80060-000	Jadlog - Jadlog Package	15.63	20.32	4	2026-03-27 13:53:47.352851	4.69	postado	567077297	2026-07-24 14:31:16.502	41999998888	52998224725	01310100	80060000	Livros e materiais escolares		0.50	10.00	15.00	20.00	Av Paulista 1000, Bela Vista, São Paulo SP 01310-100	F_3	JAD	50.00	22792664	https://painel.frenet.com.br/label?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIyNzkyNjY0&format=A4	https://rastreio.frenet.com.br/JAD/567077297	12345678901	\N	https://painel.frenet.com.br/label/Declaration?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIyNzkyNjY0&format=A4	1	\N
13	28	Maria Santos	Rua Augusta 500, Consolação, São Paulo SP 01304-000	Jadlog - Jadlog Package	15.63	20.32	4	2026-03-28 14:19:52.947125	4.69	postado	568260045	2026-07-24 14:31:17.713	11988887777	11144477735	01310100	01304000	Produtos diversos item 1		0.50	10.00	15.00	20.00	Av Paulista 1000, Bela Vista, São Paulo SP 01310-100	F_3	JAD	50.00	22826398	https://painel.frenet.com.br/label?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIyODI2Mzk4&format=A4	https://rastreio.frenet.com.br/JAD/568260045	12345678901	\N	https://painel.frenet.com.br/label/Declaration?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIyODI2Mzk4&format=A4	1	\N
12	28	Pedro Oliveira	Av Rio Branco 200, Centro, Rio de Janeiro RJ 20040-020	Jadlog - Jadlog Package	15.63	20.32	4	2026-03-28 14:19:48.355707	4.69	postado	568260043	2026-07-24 14:31:17.432	21977776666	22233366648	01310100	20040020	Produtos diversos item 2		0.50	10.00	15.00	20.00	Av Paulista 1000, Bela Vista, São Paulo SP 01310-100	F_3	JAD	50.00	22826393	https://painel.frenet.com.br/label?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIyODI2Mzkz&format=A4	https://rastreio.frenet.com.br/JAD/568260043	12345678901	\N	https://painel.frenet.com.br/label/Declaration?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIyODI2Mzkz&format=A4	1	\N
16	28	Lucia Mendes	Av Ipiranga 500, Centro, Porto Alegre RS 90160-093	Jadlog - Jadlog Package	15.63	20.32	4	2026-03-28 14:23:13.502193	4.69	postado	568265067	2026-07-24 14:31:17.995	51977772222	55566677788	01310100	90160093	Materiais lote 6		0.50	10.00	15.00	20.00	Av Paulista 1000, Bela Vista, São Paulo SP 01310-100	F_3	JAD	50.00	22826452	https://painel.frenet.com.br/label?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIyODI2NDUy&format=A4	https://rastreio.frenet.com.br/JAD/568265067	12345678901	\N	https://painel.frenet.com.br/label/Declaration?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIyODI2NDUy&format=A4	1	\N
102	29	Teste 3	Rua Teste	Jadlog	10.00	13.00	5	2026-04-07 21:09:33.947504	3.00	postado	\N	2026-04-17 12:26:13.705	11999999999		38307428	07113040			0.00	0.00	0.00	0.00	Rua Teste 123	\N	\N	\N	23152481	https://painel.frenet.com.br/label?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIzMTUyNDgx&format=A4	\N		\N	https://painel.frenet.com.br/label/Declaration?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIzMTUyNDgx&format=A4	1	\N
101	29	Teste 2	Rua Teste	Jadlog	10.00	13.00	5	2026-04-07 21:09:33.850891	3.00	postado	\N	2026-04-17 12:26:13.717	11999999999		38307428	07113040			0.00	0.00	0.00	0.00	Rua Teste 123	\N	\N	\N	23152483	https://painel.frenet.com.br/label?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIzMTUyNDgz&format=A4	\N		\N	https://painel.frenet.com.br/label/Declaration?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIzMTUyNDgz&format=A4	1	\N
103	29	Teste 4	Rua Teste	Jadlog	10.00	13.00	5	2026-04-07 21:09:33.952254	3.00	postado	\N	2026-04-17 12:26:13.717	11999999999		38307428	07113040			0.00	0.00	0.00	0.00	Rua Teste 123	\N	\N	\N	23152479	https://painel.frenet.com.br/label?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIzMTUyNDc5&format=A4	\N		\N	https://painel.frenet.com.br/label/Declaration?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIzMTUyNDc5&format=A4	1	\N
100	29	Teste 1	Rua Teste	Jadlog	10.00	13.00	5	2026-04-07 21:09:33.633431	3.00	aguardando_frenet	\N	2026-04-22 21:32:36.39	11999999999		38307428	07113040			0.00	0.00	0.00	0.00	Rua Teste 123	\N	\N	\N	\N	\N	\N		FRENET_CPF_REQUIRED: CPF/CNPJ do destinatário é obrigatório para a transportadora Jadlog. Informe o CPF do destinatário e tente novamente.	https://painel.frenet.com.br/label/Declaration?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIzMTUyNDg3&format=A4	1	\N
18	28	Joao Silva Teste Real	Rua Augusta, 1000, Apto 50, Consolacao, Sao Paulo - SP, CEP 01304001	Correios - Sedex	12.94	16.82	1	2026-04-17 12:00:40.918777	3.88	postado	AD368218826BR	2026-08-13 14:46:39.675	11988887777	11144477735	01310100	04094050	Livro de teste real		1.00	15.00	20.00	25.00	Rua Teste, 100, Centro, Sao Paulo - SP, CEP 01310100	03220	COR	50.00	23515207	https://painel.frenet.com.br/label?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIzNTE1MjA3&format=A4	https://rastreio.frenet.com.br/COR/AD368218826BR	11144477735	\N	https://painel.frenet.com.br/label/Declaration?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIzNTE1MjA3&format=A4	1	\N
19	28	Comprador Teste	Av Paulista 1000, ap 100, ap 100, São Paulo - SP	Correios - Sedex	10.94	14.22	1	2026-04-28 22:53:53.392153	3.28	cancelado	AD390403508BR	2026-04-29 11:59:04.726	11999998888	12345678909	01310100	01310100	Kit Mais Natture - 1 unidade		0.20	16.00	14.00	18.00	Rua Teste, 100, Centro, São Paulo - SP, CEP 01310100	03220	COR	14.22	23928992	https://painel.frenet.com.br/label?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIzOTI4OTky&format=A4	https://rastreio.frenet.com.br/COR/AD390403508BR	11144477735	\N	https://painel.frenet.com.br/label/Declaration?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIzOTI4OTky&format=A4	1	\N
20	28	Maria Silva	Av Paulista 100, Sao Paulo - SP	Correios - Sedex	10.94	14.22	1	2026-04-29 12:24:02.379731	3.28	postado	AD391354255BR	2026-08-25 21:07:41.048	11988887777	12345678909	01310100	01310100	kit Restart Intestinal		0.20	16.00	14.00	18.00	Rua Teste, 100, Centro, São Paulo - SP, CEP 01310100	03220	COR	14.22	23947478	https://painel.frenet.com.br/label?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIzOTQ3NDc4&format=A4	https://rastreio.frenet.com.br/COR/AD391354255BR	11144477735	\N	https://painel.frenet.com.br/label/Declaration?p=OUREREQyQjZSMTdCMVI0QzY1UkJDMDFSRTg1QUZFNDdGQjYwfDIzOTQ3NDc4&format=A4	1	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, email, password, cpf_cnpj, balance, role, blocked, default_address, phone, email_verified, email_verification_token, email_verification_token_expiry) FROM stdin;
32	axion	axionenterprise777@gmail.com	$2b$10$Skc8d4R0ZVsk16PsSXhIjeT3RxpYxBrGqSIx/xrV0vZMQKvy522a6	35991112860	0.00	user	f	\N	\N	f	2b2201acdce1861aba5da482dd332925ee296879e27eb51a5ed08a0eb571e5ed	2026-03-31 21:56:58.431
33	Vol Test	vol.test.1776887839@example.com	$2b$10$Ofo5wQYIe17WzGLGnTIfr.bqvGMn3gvlo9100O/eTpnwCfpaT1EfG	529.982.247-25	0.00	user	f	\N	\N	t	704dbb526ba2bf82e88d53d732aee33184a5c93d15412e7a92412610bd7b6de6	2026-04-23 19:57:19.313
30	Teste Verificacao	teste.verificacao@example.com	$2b$10$mep5ZFuTFUlmgnMw2bVj9eFP22f62PNdVMGgibytIxYsHabBfnb7a	123.456.789-09	0.00	user	f	\N	\N	t	\N	\N
31	Teste Inválido	verificacao.test.1774018562817@test.com	$2b$10$GS489DlQz5ebf3Nm5aAlbeekGEWOaGDcHCCgDGZhI3xmeRTyjdGX6	529.982.247-25	0.00	user	f	\N	\N	t	\N	\N
28	Cliente Teste	cliente@teste.com	$2b$10$gg5BcH/u5elUm9Fj2mcLT.6bP1uWezIlSXREMkR9DijEEIYSAaCPa	11144477735	0.00	user	f	Rua Teste, 100, Centro, São Paulo - SP, CEP 01310100	11999990001	t	\N	\N
29	Administrador	despachefacil84@gmail.com	$2b$10$gg5BcH/u5elUm9Fj2mcLT.6bP1uWezIlSXREMkR9DijEEIYSAaCPa	98765432100	0.00	admin	f	\N	11999990002	t	\N	\N
\.


--
-- Data for Name: whatsapp_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.whatsapp_messages (id, monetizze_order_id, type, status, phone, recipient_name, body, attempts, last_error, provider_message_id, sent_at, created_at, updated_at, product_code) FROM stdin;
\.


--
-- Data for Name: _managed_webhooks; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe._managed_webhooks (id, object, url, enabled_events, description, enabled, livemode, metadata, secret, status, api_version, created, updated_at, last_synced_at, account_id) FROM stdin;
we_1TGlIEDWPG7M4SENtmbfHNMg	webhook_endpoint	https://224fd9fe-a3cf-4432-b5cb-eef54c7617cd-00-14gac5xc5x218.janeway.replit.dev/api/stripe/webhook	["charge.captured", "charge.dispute.closed", "charge.dispute.created", "charge.dispute.funds_reinstated", "charge.dispute.funds_withdrawn", "charge.dispute.updated", "charge.expired", "charge.failed", "charge.pending", "charge.refund.updated", "charge.refunded", "charge.succeeded", "charge.updated", "checkout.session.async_payment_failed", "checkout.session.async_payment_succeeded", "checkout.session.completed", "checkout.session.expired", "credit_note.created", "credit_note.updated", "credit_note.voided", "customer.created", "customer.deleted", "customer.subscription.created", "customer.subscription.deleted", "customer.subscription.paused", "customer.subscription.pending_update_applied", "customer.subscription.pending_update_expired", "customer.subscription.resumed", "customer.subscription.trial_will_end", "customer.subscription.updated", "customer.tax_id.created", "customer.tax_id.deleted", "customer.tax_id.updated", "customer.updated", "entitlements.active_entitlement_summary.updated", "invoice.created", "invoice.deleted", "invoice.finalization_failed", "invoice.finalized", "invoice.marked_uncollectible", "invoice.paid", "invoice.payment_action_required", "invoice.payment_failed", "invoice.payment_succeeded", "invoice.sent", "invoice.upcoming", "invoice.updated", "invoice.voided", "payment_intent.amount_capturable_updated", "payment_intent.canceled", "payment_intent.created", "payment_intent.partially_funded", "payment_intent.payment_failed", "payment_intent.processing", "payment_intent.requires_action", "payment_intent.succeeded", "payment_method.attached", "payment_method.automatically_updated", "payment_method.card_automatically_updated", "payment_method.detached", "payment_method.updated", "plan.created", "plan.deleted", "plan.updated", "price.created", "price.deleted", "price.updated", "product.created", "product.deleted", "product.updated", "radar.early_fraud_warning.created", "radar.early_fraud_warning.updated", "refund.created", "refund.failed", "refund.updated", "review.closed", "review.opened", "setup_intent.canceled", "setup_intent.created", "setup_intent.requires_action", "setup_intent.setup_failed", "setup_intent.succeeded", "subscription_schedule.aborted", "subscription_schedule.canceled", "subscription_schedule.completed", "subscription_schedule.created", "subscription_schedule.expiring", "subscription_schedule.released", "subscription_schedule.updated"]	\N	\N	f	{"managed_by": "stripe-sync"}	whsec_CWnHMTUfnUKN7xo8B57FedNW0mccqwRG	enabled	\N	1774898170	2026-03-30 19:16:10.180924+00	2026-03-30 19:16:10.18+00	acct_1T6d4QDWPG7M4SEN
\.


--
-- Data for Name: _migrations; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe._migrations (id, name, hash, executed_at) FROM stdin;
0	initial_migration	c18983eedaa79cc2f6d92727d70c4f772256ef3d	2026-03-02 21:23:02.651456
1	products	b99ffc23df668166b94156f438bfa41818d4e80c	2026-03-02 21:23:02.655902
2	customers	33e481247ddc217f4e27ad10dfe5430097981670	2026-03-02 21:23:02.664965
3	prices	7d5ff35640651606cc24cec8a73ff7c02492ecdf	2026-03-02 21:23:02.673284
4	subscriptions	2cc6121a943c2a623c604e5ab12118a57a6c329a	2026-03-02 21:23:02.687835
5	invoices	7fbb4ccb4ed76a830552520739aaa163559771b1	2026-03-02 21:23:02.695166
6	charges	fb284ed969f033f5ce19f479b7a7e27871bddf09	2026-03-02 21:23:02.704901
7	coupons	7ed6ec4133f120675fd7888c0477b6281743fede	2026-03-02 21:23:02.713168
8	disputes	29bdb083725efe84252647f043f5f91cd0dabf43	2026-03-02 21:23:02.720211
9	events	b28cb55b5b69a9f52ef519260210cd76eea3c84e	2026-03-02 21:23:02.726949
10	payouts	69d1050b88bba1024cea4a671f9633ce7bfe25ff	2026-03-02 21:23:02.735604
11	plans	fc1ae945e86d1222a59cbcd3ae7e81a3a282a60c	2026-03-02 21:23:02.743339
12	add_updated_at	1d80945ef050a17a26e35e9983a58178262470f2	2026-03-02 21:23:02.751232
13	add_subscription_items	2aa63409bfe910add833155ad7468cdab844e0f1	2026-03-02 21:23:02.760842
14	migrate_subscription_items	8c2a798b44a8a0d83ede6f50ea7113064ecc1807	2026-03-02 21:23:02.769954
15	add_customer_deleted	6886ddfd8c129d3c4b39b59519f92618b397b395	2026-03-02 21:23:02.773706
16	add_invoice_indexes	d6bb9a09d5bdf580986ed14f55db71227a4d356d	2026-03-02 21:23:02.77626
17	drop_charges_unavailable_columns	61cd5adec4ae2c308d2c33d1b0ed203c7d074d6a	2026-03-02 21:23:02.784745
18	setup_intents	1d45d0fa47fc145f636c9e3c1ea692417fbb870d	2026-03-02 21:23:02.791522
19	payment_methods	705bdb15b50f1a97260b4f243008b8a34d23fb09	2026-03-02 21:23:02.801389
20	disputes_payment_intent_created_idx	18b2cecd7c097a7ea3b3f125f228e8790288d5ca	2026-03-02 21:23:02.811095
21	payment_intent	b1f194ff521b373c4c7cf220c0feadc253ebff0b	2026-03-02 21:23:02.81613
22	adjust_plans	e4eae536b0bc98ee14d78e818003952636ee877c	2026-03-02 21:23:02.828414
23	invoice_deleted	78e864c3146174fee7d08f05226b02d931d5b2ae	2026-03-02 21:23:02.831589
24	subscription_schedules	85fa6adb3815619bb17e1dafb00956ff548f7332	2026-03-02 21:23:02.834829
25	tax_ids	3f9a1163533f9e60a53d61dae5e451ab937584d9	2026-03-02 21:23:02.842997
26	credit_notes	e099b6b04ee607ee868d82af5193373c3fc266d2	2026-03-02 21:23:02.853862
27	add_marketing_features_to_products	6ed1774b0a9606c5937b2385d61057408193e8a7	2026-03-02 21:23:02.867163
28	early_fraud_warning	e615b0b73fa13d3b0508a1956d496d516f0ebf40	2026-03-02 21:23:02.870611
29	reviews	dd3f914139725a7934dc1062de4cc05aece77aea	2026-03-02 21:23:02.881725
30	refunds	f76c4e273eccdc96616424d73967a9bea3baac4e	2026-03-02 21:23:02.894046
31	add_default_price	6d10566a68bc632831fa25332727d8ff842caec5	2026-03-02 21:23:02.906732
32	update_subscription_items	e894858d46840ba4be5ea093cdc150728bd1d66f	2026-03-02 21:23:02.910035
33	add_last_synced_at	43124eb65b18b70c54d57d2b4fcd5dae718a200f	2026-03-02 21:23:02.912747
34	remove_foreign_keys	e72ec19f3232cf6e6b7308ebab80341c2341745f	2026-03-02 21:23:02.916725
35	checkout_sessions	dc294f5bb1a4d613be695160b38a714986800a75	2026-03-02 21:23:02.920097
36	checkout_session_line_items	82c8cfce86d68db63a9fa8de973bfe60c91342dd	2026-03-02 21:23:02.937208
37	add_features	c68a2c2b7e3808eed28c8828b2ffd3a2c9bf2bd4	2026-03-02 21:23:02.952619
38	active_entitlement	5b3858e7a52212b01e7f338cf08e29767ab362af	2026-03-02 21:23:02.963091
39	add_paused_to_subscription_status	09012b5d128f6ba25b0c8f69a1203546cf1c9f10	2026-03-02 21:23:02.978501
40	managed_webhooks	1d453dfd0e27ff0c2de97955c4ec03919af0af7f	2026-03-02 21:23:02.981019
41	rename_managed_webhooks	ad7cd1e4971a50790bf997cd157f3403d294484f	2026-03-02 21:23:03.000971
42	convert_to_jsonb_generated_columns	e0703a0e5cd9d97db53d773ada1983553e37813c	2026-03-02 21:23:03.004494
43	add_account_id	9a6beffdd0972e3657b7118b2c5001be1f815faf	2026-03-02 21:23:06.292922
44	make_account_id_required	05c1e9145220e905e0c1ca5329851acaf7e9e506	2026-03-02 21:23:06.307366
45	sync_status	2f88c4883fa885a6eaa23b8b02da958ca77a1c21	2026-03-02 21:23:06.318402
46	sync_status_per_account	b1f1f3d4fdb4b4cf4e489d4b195c7f0f97f9f27c	2026-03-02 21:23:06.333509
47	api_key_hashes	8046e4c57544b8eae277b057d201a28a4529ffe3	2026-03-02 21:23:06.363108
48	rename_reserved_columns	e32290f655550ed308a7f2dcb5b0114e49a0558e	2026-03-02 21:23:06.366807
49	remove_redundant_underscores_from_metadata_tables	96d6f3a54e17d8e19abd022a030a95a6161bf73e	2026-03-02 21:23:10.054298
50	rename_id_to_match_stripe_api	c5300c5a10081c033dab9961f4e3cd6a2440c2b6	2026-03-02 21:23:10.066526
51	remove_webhook_uuid	289bee08167858dbf4d04ca184f42681660ebb66	2026-03-02 21:23:10.315215
52	webhook_url_uniqueness	d02aec1815ce3a108b8a1def1ff24e865b26db70	2026-03-02 21:23:10.322128
\.


--
-- Data for Name: _sync_status; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe._sync_status (id, resource, status, last_synced_at, last_incremental_cursor, error_message, updated_at, account_id) FROM stdin;
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.accounts (_raw_data, first_synced_at, _last_synced_at, _updated_at, api_key_hashes) FROM stdin;
{"id": "acct_1T6d4QDWPG7M4SEN", "type": "standard", "email": null, "object": "account", "country": "US", "settings": {"payouts": {"schedule": {"interval": "daily", "delay_days": 2}, "statement_descriptor": null, "debit_negative_balances": true}, "branding": {"icon": null, "logo": null, "primary_color": null, "secondary_color": null}, "invoices": {"default_account_tax_ids": null, "hosted_payment_method_save": "offer"}, "payments": {"statement_descriptor": null, "statement_descriptor_kana": null, "statement_descriptor_kanji": null}, "dashboard": {"timezone": "Etc/UTC", "display_name": "Easy Dispatch Hub Sandbox"}, "card_issuing": {"tos_acceptance": {"ip": null, "date": null}}, "card_payments": {"statement_descriptor_prefix": null, "statement_descriptor_prefix_kana": null, "statement_descriptor_prefix_kanji": null}, "bacs_debit_payments": {"display_name": null, "service_user_number": null}, "sepa_debit_payments": {}}, "controller": {"type": "account"}, "capabilities": {}, "business_type": null, "charges_enabled": false, "payouts_enabled": false, "business_profile": {"mcc": null, "url": null, "name": null, "support_url": null, "support_email": null, "support_phone": null, "annual_revenue": null, "support_address": null, "estimated_worker_count": null, "minority_owned_business_designation": null}, "default_currency": "usd", "details_submitted": false}	2026-03-02 21:23:10.897959+00	2026-03-02 21:23:10.897959+00	2026-03-02 21:23:10.897959+00	{b280f1a42e382b2c6796bc844b699a9fef24388630c8dc87c37e2c663ae4f92c}
\.


--
-- Data for Name: active_entitlements; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.active_entitlements (_updated_at, _last_synced_at, _raw_data, _account_id) FROM stdin;
\.


--
-- Data for Name: charges; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.charges (_updated_at, _last_synced_at, _raw_data, _account_id) FROM stdin;
\.


--
-- Data for Name: checkout_session_line_items; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.checkout_session_line_items (_updated_at, _last_synced_at, _raw_data, _account_id) FROM stdin;
2026-03-24 12:59:09.32574+00	2026-03-24 12:59:08+00	{"id": "li_1TE84WDWPG7M4SENx8kqEIaQ", "price": "price_1TE84WDWPG7M4SEN27lZOwQl", "object": "item", "currency": "brl", "metadata": {}, "quantity": 1, "amount_tax": 0, "description": "Recarga de Saldo - Despache Fácil", "amount_total": 5000, "amount_discount": 0, "amount_subtotal": 5000, "checkout_session": "cs_test_a1XB330SHA2a0vmglAfiw5d9MOwjbJKlkzfjo3ff9XiSb11BkwsaQOzZva", "adjustable_quantity": null}	acct_1T6d4QDWPG7M4SEN
\.


--
-- Data for Name: checkout_sessions; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.checkout_sessions (_updated_at, _last_synced_at, _raw_data, _account_id) FROM stdin;
2026-03-24 12:59:08.850288+00	2026-03-24 12:59:08+00	{"id": "cs_test_a1XB330SHA2a0vmglAfiw5d9MOwjbJKlkzfjo3ff9XiSb11BkwsaQOzZva", "url": null, "mode": "payment", "locale": null, "object": "checkout.session", "status": "expired", "consent": null, "created": 1774270749, "invoice": null, "ui_mode": "hosted", "currency": "brl", "customer": null, "livemode": false, "metadata": {"type": "balance_topup", "amount": "50", "userId": "29"}, "discounts": [], "cancel_url": "http://localhost:5000/dashboard?payment=cancelled", "expires_at": 1774357148, "custom_text": {"submit": null, "after_submit": null, "shipping_address": null, "terms_of_service_acceptance": null}, "permissions": null, "submit_type": null, "success_url": "http://localhost:5000/dashboard?payment=success&session_id={CHECKOUT_SESSION_ID}", "amount_total": 5000, "payment_link": null, "setup_intent": null, "subscription": null, "automatic_tax": {"status": null, "enabled": false, "provider": null, "liability": null}, "client_secret": null, "custom_fields": [], "shipping_cost": null, "total_details": {"amount_tax": 0, "amount_discount": 0, "amount_shipping": 0}, "customer_email": null, "origin_context": null, "payment_intent": null, "payment_status": "unpaid", "recovered_from": null, "wallet_options": null, "amount_subtotal": 5000, "adaptive_pricing": {"enabled": true}, "after_expiration": null, "customer_account": null, "customer_details": null, "invoice_creation": {"enabled": false, "invoice_data": {"footer": null, "issuer": null, "metadata": {}, "description": null, "custom_fields": null, "account_tax_ids": null, "rendering_options": null}}, "shipping_options": [], "branding_settings": {"icon": null, "logo": null, "font_family": "default", "border_style": "rounded", "button_color": "#0074d4", "display_name": "Easy Dispatch Hub Sandbox", "background_color": "#ffffff"}, "customer_creation": "if_required", "consent_collection": null, "client_reference_id": null, "currency_conversion": null, "payment_method_types": ["card", "pix"], "allow_promotion_codes": null, "collected_information": null, "integration_identifier": null, "payment_method_options": {"pix": {"expires_after_seconds": 1800}, "card": {"request_three_d_secure": "automatic"}}, "phone_number_collection": {"enabled": false}, "payment_method_collection": "if_required", "billing_address_collection": null, "shipping_address_collection": null, "saved_payment_method_options": null, "payment_method_configuration_details": null}	acct_1T6d4QDWPG7M4SEN
\.


--
-- Data for Name: coupons; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.coupons (_updated_at, _last_synced_at, _raw_data) FROM stdin;
\.


--
-- Data for Name: credit_notes; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.credit_notes (_last_synced_at, _raw_data, _account_id) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.customers (_updated_at, _last_synced_at, _raw_data, _account_id) FROM stdin;
\.


--
-- Data for Name: disputes; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.disputes (_updated_at, _last_synced_at, _raw_data, _account_id) FROM stdin;
\.


--
-- Data for Name: early_fraud_warnings; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.early_fraud_warnings (_updated_at, _last_synced_at, _raw_data, _account_id) FROM stdin;
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.events (_updated_at, _last_synced_at, _raw_data) FROM stdin;
\.


--
-- Data for Name: features; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.features (_updated_at, _last_synced_at, _raw_data, _account_id) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.invoices (_updated_at, _last_synced_at, _raw_data, _account_id) FROM stdin;
\.


--
-- Data for Name: payment_intents; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.payment_intents (_last_synced_at, _raw_data, _account_id) FROM stdin;
\.


--
-- Data for Name: payment_methods; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.payment_methods (_last_synced_at, _raw_data, _account_id) FROM stdin;
\.


--
-- Data for Name: payouts; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.payouts (_updated_at, _last_synced_at, _raw_data) FROM stdin;
\.


--
-- Data for Name: plans; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.plans (_updated_at, _last_synced_at, _raw_data, _account_id) FROM stdin;
\.


--
-- Data for Name: prices; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.prices (_updated_at, _last_synced_at, _raw_data, _account_id) FROM stdin;
2026-03-24 12:59:09.312404+00	2026-03-24 12:59:09.312+00	{"id": "price_1TE84WDWPG7M4SEN27lZOwQl", "type": "one_time", "active": false, "object": "price", "created": 1774270748, "product": "prod_U5sfqX6t1gVzbj", "currency": "brl", "livemode": false, "metadata": {}, "nickname": null, "recurring": null, "lookup_key": null, "tiers_mode": null, "unit_amount": 5000, "tax_behavior": "unspecified", "billing_scheme": "per_unit", "custom_unit_amount": null, "transform_quantity": null, "unit_amount_decimal": "5000"}	acct_1T6d4QDWPG7M4SEN
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.products (_updated_at, _last_synced_at, _raw_data, _account_id) FROM stdin;
\.


--
-- Data for Name: refunds; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.refunds (_updated_at, _last_synced_at, _raw_data, _account_id) FROM stdin;
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.reviews (_updated_at, _last_synced_at, _raw_data, _account_id) FROM stdin;
\.


--
-- Data for Name: setup_intents; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.setup_intents (_last_synced_at, _raw_data, _account_id) FROM stdin;
\.


--
-- Data for Name: subscription_items; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.subscription_items (_last_synced_at, _raw_data, _account_id) FROM stdin;
\.


--
-- Data for Name: subscription_schedules; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.subscription_schedules (_last_synced_at, _raw_data, _account_id) FROM stdin;
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.subscriptions (_updated_at, _last_synced_at, _raw_data, _account_id) FROM stdin;
\.


--
-- Data for Name: tax_ids; Type: TABLE DATA; Schema: stripe; Owner: -
--

COPY stripe.tax_ids (_last_synced_at, _raw_data, _account_id) FROM stdin;
\.


--
-- Name: cart_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cart_items_id_seq', 17, true);


--
-- Name: email_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_logs_id_seq', 4, true);


--
-- Name: monetizze_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.monetizze_orders_id_seq', 6, true);


--
-- Name: payment_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_orders_id_seq', 4, true);


--
-- Name: platform_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.platform_settings_id_seq', 10, true);


--
-- Name: processed_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.processed_payments_id_seq', 1, false);


--
-- Name: product_materials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_materials_id_seq', 2, true);


--
-- Name: quote_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.quote_history_id_seq', 54, true);


--
-- Name: shipments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shipments_id_seq', 22, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 33, true);


--
-- Name: whatsapp_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.whatsapp_messages_id_seq', 1, false);


--
-- Name: _sync_status_id_seq; Type: SEQUENCE SET; Schema: stripe; Owner: -
--

SELECT pg_catalog.setval('stripe._sync_status_id_seq', 1, false);


--
-- Name: cart_items cart_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_pkey PRIMARY KEY (id);


--
-- Name: email_logs email_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_pkey PRIMARY KEY (id);


--
-- Name: monetizze_orders monetizze_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monetizze_orders
    ADD CONSTRAINT monetizze_orders_pkey PRIMARY KEY (id);


--
-- Name: monetizze_orders monetizze_orders_sale_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monetizze_orders
    ADD CONSTRAINT monetizze_orders_sale_code_unique UNIQUE (sale_code);


--
-- Name: payment_orders payment_orders_asaas_payment_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_orders
    ADD CONSTRAINT payment_orders_asaas_payment_id_unique UNIQUE (asaas_payment_id);


--
-- Name: payment_orders payment_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_orders
    ADD CONSTRAINT payment_orders_pkey PRIMARY KEY (id);


--
-- Name: platform_settings platform_settings_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_settings
    ADD CONSTRAINT platform_settings_key_unique UNIQUE (key);


--
-- Name: platform_settings platform_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_settings
    ADD CONSTRAINT platform_settings_pkey PRIMARY KEY (id);


--
-- Name: processed_payments processed_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.processed_payments
    ADD CONSTRAINT processed_payments_pkey PRIMARY KEY (id);


--
-- Name: processed_payments processed_payments_stripe_session_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.processed_payments
    ADD CONSTRAINT processed_payments_stripe_session_id_unique UNIQUE (stripe_session_id);


--
-- Name: product_materials product_materials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_materials
    ADD CONSTRAINT product_materials_pkey PRIMARY KEY (id);


--
-- Name: product_materials product_materials_product_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_materials
    ADD CONSTRAINT product_materials_product_code_unique UNIQUE (product_code);


--
-- Name: quote_history quote_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_history
    ADD CONSTRAINT quote_history_pkey PRIMARY KEY (id);


--
-- Name: shipments shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: whatsapp_messages whatsapp_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_messages
    ADD CONSTRAINT whatsapp_messages_pkey PRIMARY KEY (id);


--
-- Name: _migrations _migrations_name_key; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe._migrations
    ADD CONSTRAINT _migrations_name_key UNIQUE (name);


--
-- Name: _migrations _migrations_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe._migrations
    ADD CONSTRAINT _migrations_pkey PRIMARY KEY (id);


--
-- Name: _sync_status _sync_status_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe._sync_status
    ADD CONSTRAINT _sync_status_pkey PRIMARY KEY (id);


--
-- Name: _sync_status _sync_status_resource_account_key; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe._sync_status
    ADD CONSTRAINT _sync_status_resource_account_key UNIQUE (resource, account_id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: active_entitlements active_entitlements_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.active_entitlements
    ADD CONSTRAINT active_entitlements_pkey PRIMARY KEY (id);


--
-- Name: charges charges_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.charges
    ADD CONSTRAINT charges_pkey PRIMARY KEY (id);


--
-- Name: checkout_session_line_items checkout_session_line_items_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.checkout_session_line_items
    ADD CONSTRAINT checkout_session_line_items_pkey PRIMARY KEY (id);


--
-- Name: checkout_sessions checkout_sessions_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.checkout_sessions
    ADD CONSTRAINT checkout_sessions_pkey PRIMARY KEY (id);


--
-- Name: coupons coupons_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.coupons
    ADD CONSTRAINT coupons_pkey PRIMARY KEY (id);


--
-- Name: credit_notes credit_notes_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.credit_notes
    ADD CONSTRAINT credit_notes_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: disputes disputes_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.disputes
    ADD CONSTRAINT disputes_pkey PRIMARY KEY (id);


--
-- Name: early_fraud_warnings early_fraud_warnings_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.early_fraud_warnings
    ADD CONSTRAINT early_fraud_warnings_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: features features_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.features
    ADD CONSTRAINT features_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: _managed_webhooks managed_webhooks_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe._managed_webhooks
    ADD CONSTRAINT managed_webhooks_pkey PRIMARY KEY (id);


--
-- Name: _managed_webhooks managed_webhooks_url_account_unique; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe._managed_webhooks
    ADD CONSTRAINT managed_webhooks_url_account_unique UNIQUE (url, account_id);


--
-- Name: payment_intents payment_intents_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.payment_intents
    ADD CONSTRAINT payment_intents_pkey PRIMARY KEY (id);


--
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (id);


--
-- Name: payouts payouts_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.payouts
    ADD CONSTRAINT payouts_pkey PRIMARY KEY (id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: prices prices_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.prices
    ADD CONSTRAINT prices_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: refunds refunds_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.refunds
    ADD CONSTRAINT refunds_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: setup_intents setup_intents_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.setup_intents
    ADD CONSTRAINT setup_intents_pkey PRIMARY KEY (id);


--
-- Name: subscription_items subscription_items_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.subscription_items
    ADD CONSTRAINT subscription_items_pkey PRIMARY KEY (id);


--
-- Name: subscription_schedules subscription_schedules_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.subscription_schedules
    ADD CONSTRAINT subscription_schedules_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: tax_ids tax_ids_pkey; Type: CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.tax_ids
    ADD CONSTRAINT tax_ids_pkey PRIMARY KEY (id);


--
-- Name: whatsapp_messages_order_type_uniq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX whatsapp_messages_order_type_uniq ON public.whatsapp_messages USING btree (monetizze_order_id, type, product_code);


--
-- Name: active_entitlements_lookup_key_key; Type: INDEX; Schema: stripe; Owner: -
--

CREATE UNIQUE INDEX active_entitlements_lookup_key_key ON stripe.active_entitlements USING btree (lookup_key) WHERE (lookup_key IS NOT NULL);


--
-- Name: features_lookup_key_key; Type: INDEX; Schema: stripe; Owner: -
--

CREATE UNIQUE INDEX features_lookup_key_key ON stripe.features USING btree (lookup_key) WHERE (lookup_key IS NOT NULL);


--
-- Name: idx_accounts_api_key_hashes; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX idx_accounts_api_key_hashes ON stripe.accounts USING gin (api_key_hashes);


--
-- Name: idx_accounts_business_name; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX idx_accounts_business_name ON stripe.accounts USING btree (business_name);


--
-- Name: idx_sync_status_resource_account; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX idx_sync_status_resource_account ON stripe._sync_status USING btree (resource, account_id);


--
-- Name: stripe_active_entitlements_customer_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_active_entitlements_customer_idx ON stripe.active_entitlements USING btree (customer);


--
-- Name: stripe_active_entitlements_feature_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_active_entitlements_feature_idx ON stripe.active_entitlements USING btree (feature);


--
-- Name: stripe_checkout_session_line_items_price_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_checkout_session_line_items_price_idx ON stripe.checkout_session_line_items USING btree (price);


--
-- Name: stripe_checkout_session_line_items_session_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_checkout_session_line_items_session_idx ON stripe.checkout_session_line_items USING btree (checkout_session);


--
-- Name: stripe_checkout_sessions_customer_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_checkout_sessions_customer_idx ON stripe.checkout_sessions USING btree (customer);


--
-- Name: stripe_checkout_sessions_invoice_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_checkout_sessions_invoice_idx ON stripe.checkout_sessions USING btree (invoice);


--
-- Name: stripe_checkout_sessions_payment_intent_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_checkout_sessions_payment_intent_idx ON stripe.checkout_sessions USING btree (payment_intent);


--
-- Name: stripe_checkout_sessions_subscription_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_checkout_sessions_subscription_idx ON stripe.checkout_sessions USING btree (subscription);


--
-- Name: stripe_credit_notes_customer_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_credit_notes_customer_idx ON stripe.credit_notes USING btree (customer);


--
-- Name: stripe_credit_notes_invoice_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_credit_notes_invoice_idx ON stripe.credit_notes USING btree (invoice);


--
-- Name: stripe_dispute_created_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_dispute_created_idx ON stripe.disputes USING btree (created);


--
-- Name: stripe_early_fraud_warnings_charge_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_early_fraud_warnings_charge_idx ON stripe.early_fraud_warnings USING btree (charge);


--
-- Name: stripe_early_fraud_warnings_payment_intent_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_early_fraud_warnings_payment_intent_idx ON stripe.early_fraud_warnings USING btree (payment_intent);


--
-- Name: stripe_invoices_customer_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_invoices_customer_idx ON stripe.invoices USING btree (customer);


--
-- Name: stripe_invoices_subscription_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_invoices_subscription_idx ON stripe.invoices USING btree (subscription);


--
-- Name: stripe_managed_webhooks_enabled_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_managed_webhooks_enabled_idx ON stripe._managed_webhooks USING btree (enabled);


--
-- Name: stripe_managed_webhooks_status_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_managed_webhooks_status_idx ON stripe._managed_webhooks USING btree (status);


--
-- Name: stripe_payment_intents_customer_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_payment_intents_customer_idx ON stripe.payment_intents USING btree (customer);


--
-- Name: stripe_payment_intents_invoice_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_payment_intents_invoice_idx ON stripe.payment_intents USING btree (invoice);


--
-- Name: stripe_payment_methods_customer_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_payment_methods_customer_idx ON stripe.payment_methods USING btree (customer);


--
-- Name: stripe_refunds_charge_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_refunds_charge_idx ON stripe.refunds USING btree (charge);


--
-- Name: stripe_refunds_payment_intent_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_refunds_payment_intent_idx ON stripe.refunds USING btree (payment_intent);


--
-- Name: stripe_reviews_charge_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_reviews_charge_idx ON stripe.reviews USING btree (charge);


--
-- Name: stripe_reviews_payment_intent_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_reviews_payment_intent_idx ON stripe.reviews USING btree (payment_intent);


--
-- Name: stripe_setup_intents_customer_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_setup_intents_customer_idx ON stripe.setup_intents USING btree (customer);


--
-- Name: stripe_tax_ids_customer_idx; Type: INDEX; Schema: stripe; Owner: -
--

CREATE INDEX stripe_tax_ids_customer_idx ON stripe.tax_ids USING btree (customer);


--
-- Name: _managed_webhooks handle_updated_at; Type: TRIGGER; Schema: stripe; Owner: -
--

CREATE TRIGGER handle_updated_at BEFORE UPDATE ON stripe._managed_webhooks FOR EACH ROW EXECUTE FUNCTION public.set_updated_at_metadata();


--
-- Name: _sync_status handle_updated_at; Type: TRIGGER; Schema: stripe; Owner: -
--

CREATE TRIGGER handle_updated_at BEFORE UPDATE ON stripe._sync_status FOR EACH ROW EXECUTE FUNCTION public.set_updated_at_metadata();


--
-- Name: accounts handle_updated_at; Type: TRIGGER; Schema: stripe; Owner: -
--

CREATE TRIGGER handle_updated_at BEFORE UPDATE ON stripe.accounts FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: active_entitlements handle_updated_at; Type: TRIGGER; Schema: stripe; Owner: -
--

CREATE TRIGGER handle_updated_at BEFORE UPDATE ON stripe.active_entitlements FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: charges handle_updated_at; Type: TRIGGER; Schema: stripe; Owner: -
--

CREATE TRIGGER handle_updated_at BEFORE UPDATE ON stripe.charges FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: checkout_session_line_items handle_updated_at; Type: TRIGGER; Schema: stripe; Owner: -
--

CREATE TRIGGER handle_updated_at BEFORE UPDATE ON stripe.checkout_session_line_items FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: checkout_sessions handle_updated_at; Type: TRIGGER; Schema: stripe; Owner: -
--

CREATE TRIGGER handle_updated_at BEFORE UPDATE ON stripe.checkout_sessions FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: coupons handle_updated_at; Type: TRIGGER; Schema: stripe; Owner: -
--

CREATE TRIGGER handle_updated_at BEFORE UPDATE ON stripe.coupons FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: customers handle_updated_at; Type: TRIGGER; Schema: stripe; Owner: -
--

CREATE TRIGGER handle_updated_at BEFORE UPDATE ON stripe.customers FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: disputes handle_updated_at; Type: TRIGGER; Schema: stripe; Owner: -
--

CREATE TRIGGER handle_updated_at BEFORE UPDATE ON stripe.disputes FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: early_fraud_warnings handle_updated_at; Type: TRIGGER; Schema: stripe; Owner: -
--

CREATE TRIGGER handle_updated_at BEFORE UPDATE ON stripe.early_fraud_warnings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: events handle_updated_at; Type: TRIGGER; Schema: stripe; Owner: -
--

CREATE TRIGGER handle_updated_at BEFORE UPDATE ON stripe.events FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: features handle_updated_at; Type: TRIGGER; Schema: stripe; Owner: -
--

CREATE TRIGGER handle_updated_at BEFORE UPDATE ON stripe.features FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: invoices handle_updated_at; Type: TRIGGER; Schema: stripe; Owner: -
--

CREATE TRIGGER handle_updated_at BEFORE UPDATE ON stripe.invoices FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: payouts handle_updated_at; Type: TRIGGER; Schema: stripe; Owner: -
--

CREATE TRIGGER handle_updated_at BEFORE UPDATE ON stripe.payouts FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: plans handle_updated_at; Type: TRIGGER; Schema: stripe; Owner: -
--

CREATE TRIGGER handle_updated_at BEFORE UPDATE ON stripe.plans FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: prices handle_updated_at; Type: TRIGGER; Schema: stripe; Owner: -
--

CREATE TRIGGER handle_updated_at BEFORE UPDATE ON stripe.prices FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: products handle_updated_at; Type: TRIGGER; Schema: stripe; Owner: -
--

CREATE TRIGGER handle_updated_at BEFORE UPDATE ON stripe.products FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: refunds handle_updated_at; Type: TRIGGER; Schema: stripe; Owner: -
--

CREATE TRIGGER handle_updated_at BEFORE UPDATE ON stripe.refunds FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: reviews handle_updated_at; Type: TRIGGER; Schema: stripe; Owner: -
--

CREATE TRIGGER handle_updated_at BEFORE UPDATE ON stripe.reviews FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: subscriptions handle_updated_at; Type: TRIGGER; Schema: stripe; Owner: -
--

CREATE TRIGGER handle_updated_at BEFORE UPDATE ON stripe.subscriptions FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: active_entitlements fk_active_entitlements_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.active_entitlements
    ADD CONSTRAINT fk_active_entitlements_account FOREIGN KEY (_account_id) REFERENCES stripe.accounts(id);


--
-- Name: charges fk_charges_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.charges
    ADD CONSTRAINT fk_charges_account FOREIGN KEY (_account_id) REFERENCES stripe.accounts(id);


--
-- Name: checkout_session_line_items fk_checkout_session_line_items_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.checkout_session_line_items
    ADD CONSTRAINT fk_checkout_session_line_items_account FOREIGN KEY (_account_id) REFERENCES stripe.accounts(id);


--
-- Name: checkout_sessions fk_checkout_sessions_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.checkout_sessions
    ADD CONSTRAINT fk_checkout_sessions_account FOREIGN KEY (_account_id) REFERENCES stripe.accounts(id);


--
-- Name: credit_notes fk_credit_notes_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.credit_notes
    ADD CONSTRAINT fk_credit_notes_account FOREIGN KEY (_account_id) REFERENCES stripe.accounts(id);


--
-- Name: customers fk_customers_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.customers
    ADD CONSTRAINT fk_customers_account FOREIGN KEY (_account_id) REFERENCES stripe.accounts(id);


--
-- Name: disputes fk_disputes_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.disputes
    ADD CONSTRAINT fk_disputes_account FOREIGN KEY (_account_id) REFERENCES stripe.accounts(id);


--
-- Name: early_fraud_warnings fk_early_fraud_warnings_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.early_fraud_warnings
    ADD CONSTRAINT fk_early_fraud_warnings_account FOREIGN KEY (_account_id) REFERENCES stripe.accounts(id);


--
-- Name: features fk_features_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.features
    ADD CONSTRAINT fk_features_account FOREIGN KEY (_account_id) REFERENCES stripe.accounts(id);


--
-- Name: invoices fk_invoices_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.invoices
    ADD CONSTRAINT fk_invoices_account FOREIGN KEY (_account_id) REFERENCES stripe.accounts(id);


--
-- Name: _managed_webhooks fk_managed_webhooks_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe._managed_webhooks
    ADD CONSTRAINT fk_managed_webhooks_account FOREIGN KEY (account_id) REFERENCES stripe.accounts(id);


--
-- Name: payment_intents fk_payment_intents_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.payment_intents
    ADD CONSTRAINT fk_payment_intents_account FOREIGN KEY (_account_id) REFERENCES stripe.accounts(id);


--
-- Name: payment_methods fk_payment_methods_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.payment_methods
    ADD CONSTRAINT fk_payment_methods_account FOREIGN KEY (_account_id) REFERENCES stripe.accounts(id);


--
-- Name: plans fk_plans_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.plans
    ADD CONSTRAINT fk_plans_account FOREIGN KEY (_account_id) REFERENCES stripe.accounts(id);


--
-- Name: prices fk_prices_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.prices
    ADD CONSTRAINT fk_prices_account FOREIGN KEY (_account_id) REFERENCES stripe.accounts(id);


--
-- Name: products fk_products_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.products
    ADD CONSTRAINT fk_products_account FOREIGN KEY (_account_id) REFERENCES stripe.accounts(id);


--
-- Name: refunds fk_refunds_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.refunds
    ADD CONSTRAINT fk_refunds_account FOREIGN KEY (_account_id) REFERENCES stripe.accounts(id);


--
-- Name: reviews fk_reviews_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.reviews
    ADD CONSTRAINT fk_reviews_account FOREIGN KEY (_account_id) REFERENCES stripe.accounts(id);


--
-- Name: setup_intents fk_setup_intents_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.setup_intents
    ADD CONSTRAINT fk_setup_intents_account FOREIGN KEY (_account_id) REFERENCES stripe.accounts(id);


--
-- Name: subscription_items fk_subscription_items_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.subscription_items
    ADD CONSTRAINT fk_subscription_items_account FOREIGN KEY (_account_id) REFERENCES stripe.accounts(id);


--
-- Name: subscription_schedules fk_subscription_schedules_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.subscription_schedules
    ADD CONSTRAINT fk_subscription_schedules_account FOREIGN KEY (_account_id) REFERENCES stripe.accounts(id);


--
-- Name: subscriptions fk_subscriptions_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.subscriptions
    ADD CONSTRAINT fk_subscriptions_account FOREIGN KEY (_account_id) REFERENCES stripe.accounts(id);


--
-- Name: _sync_status fk_sync_status_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe._sync_status
    ADD CONSTRAINT fk_sync_status_account FOREIGN KEY (account_id) REFERENCES stripe.accounts(id);


--
-- Name: tax_ids fk_tax_ids_account; Type: FK CONSTRAINT; Schema: stripe; Owner: -
--

ALTER TABLE ONLY stripe.tax_ids
    ADD CONSTRAINT fk_tax_ids_account FOREIGN KEY (_account_id) REFERENCES stripe.accounts(id);


--
-- PostgreSQL database dump complete
--

\unrestrict qzmtuFdXyNwERvAvhn6bgXDqz82f0R0b8OG2BQoYaH9s0ZrURQ5AXJqeWdEeMP6

